
import React, { useState, useEffect } from 'react';
import { Feature } from './types.ts'; // Theme type removed
import { APP_TITLE, FEATURES_MENU } from './constants.tsx';
import Navbar from './components/Navbar.tsx';
// LoadingSpinner import removed as it's not used directly here if all dark classes removed from it.
// Re-evaluate if LoadingSpinner is used by children and still needs specific handling.

// Static imports for all feature components
import AutoFormatting from './components/AutoFormatting.tsx';
import SampleDocumentViewer from './components/SampleDocumentViewer.tsx';
import BibliographyGenerator from './components/BibliographyGenerator.tsx';
import SubmissionChecklist from './components/SubmissionChecklist.tsx';
import ParaphrasingTool from './components/ParaphrasingTool.tsx';
import LogicAnalysis from './components/LogicAnalysis.tsx';
import DataVizRecommender from './components/DataVizRecommender.tsx';
import PresentationOutline from './components/PresentationOutline.tsx';
import ThesisDraftGenerator from './components/ThesisDraftGenerator.tsx';
import InformationPage from './components/InformationPage.tsx';

const App: React.FC = () => {
  const [activeFeature, setActiveFeature] = useState<Feature>(() => {
    const storedFeature = localStorage.getItem('activeFeature') as Feature | null;
    if (storedFeature && Object.values(Feature).includes(storedFeature)) {
        return storedFeature;
    }
    return Feature.AI_THESIS_DRAFT_GENERATOR; // Default feature
  });
  
  const [sessionDuration, setSessionDuration] = useState<string>("00:00:00");
  const [startTime] = useState<number>(Date.now());

  useEffect(() => {
    localStorage.setItem('activeFeature', activeFeature);
  }, [activeFeature]);

  useEffect(() => {
    const timer = setInterval(() => {
      const now = Date.now();
      const diff = now - startTime;
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);
      setSessionDuration(
        `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
      );
    }, 1000);
    return () => clearInterval(timer);
  }, [startTime]);

  const renderFeatureComponent = () => {
    switch (activeFeature) {
      case Feature.AUTO_FORMATTING:
        return <AutoFormatting />;
      case Feature.SAMPLE_DOCS:
        return <SampleDocumentViewer />;
      case Feature.BIBLIOGRAPHY:
        return <BibliographyGenerator />;
      case Feature.CHECKLIST:
        return <SubmissionChecklist />;
      case Feature.PARAPHRASING:
        return <ParaphrasingTool />;
      case Feature.LOGIC_ANALYSIS: 
        return <LogicAnalysis />;
      case Feature.DATA_VIZ:
        return <DataVizRecommender />;
      case Feature.PRESENTATION:
        return <PresentationOutline />;
      case Feature.AI_THESIS_DRAFT_GENERATOR:
        return <ThesisDraftGenerator />;
      case Feature.INFORMATION: 
        return <InformationPage />;
      default:
        // Attempt to find if the stored activeFeature is valid, otherwise default to INFORMATION
        const defaultFeatureExists = FEATURES_MENU.find(f => f.id === activeFeature);
        if (!defaultFeatureExists && FEATURES_MENU.find(f => f.id === Feature.INFORMATION)) {
            setActiveFeature(Feature.INFORMATION); 
            return <InformationPage />;
        }
        // Fallback if even INFORMATION feature is somehow not found or if activeFeature is truly invalid
        return <div className="text-center p-8 text-gray-700">Pilih fitur dari menu.</div>;
    }
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gray-100 text-gray-800">
      <Navbar 
        activeFeature={activeFeature} 
        setActiveFeature={setActiveFeature} 
        sessionDuration={sessionDuration}
        // currentTheme and toggleTheme props removed
      />
      <main className="flex-1 p-4 md:p-8 overflow-y-auto bg-white text-gray-800 shadow-xl md:rounded-l-xl">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-700 mb-6 text-center">{APP_TITLE}</h1>
          <h2 className="text-xl md:text-2xl font-semibold text-indigo-600 mb-8 text-center">
            {FEATURES_MENU.find(f => f.id === activeFeature)?.name || "Informasi Aplikasi"}
          </h2>
          {renderFeatureComponent()}
        </div>
      </main>
    </div>
  );
};

export default App;