
import React, { useState, useCallback } from 'react';
import SectionCard from './SectionCard.tsx';
import { ClipboardIcon, CheckIcon, DocumentTextIcon } from '../constants.tsx';
import LoadingSpinner from './LoadingSpinner.tsx';
import { getFormattingAdvice } from '../services/geminiService.ts';
import { GeminiResponse } from '../types.ts';

const AutoFormatting: React.FC = () => {
  const [textSnippet, setTextSnippet] = useState('');
  const [documentContext, setDocumentContext] = useState('');
  const [advice, setAdvice] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [copiedStatic, setCopiedStatic] = useState(false);

  const formattingInfoStatic = `
=== STYLESHEET OTOMATIS UMUM (Contoh untuk Microsoft Word) ===

Heading 1 (BAB):
  Font: Times New Roman, Ukuran: 14pt, Gaya: Bold, ALL CAPS, Perataan: Tengah

Heading 2 (Sub-bab):
  Font: Times New Roman, Ukuran: 12pt, Gaya: Bold, Title Case, Perataan: Kiri

Body Text (Isi Teks):
  Font: Times New Roman, Ukuran: 12pt, Perataan: Justify, Spasi: 1.5 Lines

Block Quote (Kutipan Langsung >40 kata):
  Font: Times New Roman, Ukuran: 12pt, Gaya: Italic, Indentasi: 0.5" kiri, Spasi: 1.0 Line

=== MASTER PAGE LAYOUT UMUM ===
Margin: Atas: 4 cm, Kanan: 3 cm, Bawah: 3 cm, Kiri: 3 cm
Header: Nama pendek skripsi / Judul bab (Font 10pt, Kanan)
Footer: Nomor halaman (Romawi untuk prelim, Arab untuk isi, Tengah bawah)
`;

  const handleGetAdvice = useCallback(async () => {
    if (!textSnippet.trim() || !documentContext.trim()) {
      setError("Masukkan cuplikan teks dan konteks dokumen terlebih dahulu.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setAdvice('');
    try {
      const response: GeminiResponse = await getFormattingAdvice(textSnippet, documentContext);
      if (response.text.startsWith("Error:")) {
        setError(response.text);
      } else {
        setAdvice(response.text);
      }
    } catch (e: any) {
      setError(e.message || "Gagal mendapatkan saran formatting dari Adios.");
    } finally {
      setIsLoading(false);
    }
  }, [textSnippet, documentContext]);

  const handleCopy = (textToCopy: string, type: 'advice' | 'static') => {
    navigator.clipboard.writeText(textToCopy);
    if (type === 'advice') {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } else {
      setCopiedStatic(true);
      setTimeout(() => setCopiedStatic(false), 2000);
    }
  };

  return (
    <SectionCard 
      title="Saran Auto-Formatting Dokumen dari Adios"
      description="Masukkan cuplikan teks dan jelaskan konteks dokumennya (misal: 'Abstrak Skripsi Psikologi', 'Bab II Tinjauan Pustaka Tesis Teknik'). Adios akan memberikan saran formatting spesifik."
    >
      <div className="space-y-4">
        <div>
          <label htmlFor="documentContext" className="block text-sm font-medium text-gray-700 mb-1">
            Konteks Dokumen/Bagian:
          </label>
          <input
            type="text"
            id="documentContext"
            value={documentContext}
            onChange={(e) => setDocumentContext(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
            placeholder="Contoh: Latar Belakang Bab I Skripsi Hukum"
            disabled={isLoading}
          />
        </div>
        <div>
          <label htmlFor="textSnippet" className="block text-sm font-medium text-gray-700 mb-1">
            Cuplikan Teks Anda:
          </label>
          <textarea
            id="textSnippet"
            value={textSnippet}
            onChange={(e) => setTextSnippet(e.target.value)}
            rows={5}
            className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
            placeholder="Tempelkan atau ketik cuplikan teks di sini..."
            disabled={isLoading}
          />
        </div>
        <button
          onClick={handleGetAdvice}
          disabled={isLoading || !textSnippet.trim() || !documentContext.trim()}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-4 rounded-lg shadow-md disabled:opacity-50 flex items-center justify-center transition-colors"
        >
          {isLoading ? <LoadingSpinner /> : (
            <>
              <DocumentTextIcon className="w-5 h-5 mr-2" />
              Dapatkan Saran Formatting dari Adios
            </>
          )}
        </button>

        {error && <p role="alert" aria-live="assertive" className="text-sm text-red-600 bg-red-100 p-3 rounded-lg border border-red-200">{error}</p>}
        
        {advice && (
          <div className="mt-6">
            <h4 className="text-md font-semibold text-gray-700 mb-2">Saran Formatting dari Adios:</h4>
            <div className="relative">
              <button
                onClick={() => handleCopy(advice, 'advice')}
                className="absolute top-2 right-2 bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-md text-xs flex items-center transition-colors"
                title="Salin Saran ke Clipboard"
                aria-label="Salin Saran dari Adios"
              >
                {copied ? <CheckIcon className="w-4 h-4 mr-1 text-green-500" /> : <ClipboardIcon className="w-4 h-4 mr-1" />}
                {copied ? 'Tersalin!' : 'Salin'}
              </button>
              <pre className="text-sm leading-relaxed whitespace-pre-wrap p-4 rounded-lg max-h-[600px] overflow-y-auto">
                {advice.trim()}
              </pre>
            </div>
          </div>
        )}
      </div>

      <div className="mt-8 pt-6 border-t border-gray-200">
         <h4 className="text-md font-semibold text-gray-600 mb-2">Panduan Umum Formatting (Sebagai Referensi Cepat):</h4>
         <div className="relative">
            <button
                onClick={() => handleCopy(formattingInfoStatic, 'static')}
                className="absolute top-2 right-2 bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-md text-xs flex items-center transition-colors"
                title="Salin Info Umum ke Clipboard"
                aria-label="Salin Info Umum Formatting"
            >
                {copiedStatic ? <CheckIcon className="w-4 h-4 mr-1 text-green-500" /> : <ClipboardIcon className="w-4 h-4 mr-1" />}
                {copiedStatic ? 'Tersalin!' : 'Salin'}
            </button>
            <pre className="text-xs leading-relaxed whitespace-pre-wrap p-3 rounded-lg max-h-[300px] overflow-y-auto">
                {formattingInfoStatic.trim()}
            </pre>
         </div>
         <p className="text-xs text-gray-500 mt-2">
            <strong>Catatan:</strong> Informasi di atas adalah panduan umum. Saran Adios yang lebih spesifik akan muncul setelah Anda memasukkan input. Selalu periksa panduan resmi dari fakultas/universitas Anda.
         </p>
      </div>
    </SectionCard>
  );
};

export default AutoFormatting;