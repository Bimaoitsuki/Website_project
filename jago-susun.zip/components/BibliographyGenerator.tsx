
import React, { useState, useCallback } from 'react';
import { CitationStyle, GroundingChunk, GeminiResponse } from '../types.ts';
import { formatReferences, suggestRelevantSources } from '../services/geminiService.ts';
import SectionCard from './SectionCard.tsx';
import LoadingSpinner from './LoadingSpinner.tsx';
import { ClipboardIcon, CheckIcon, ListBulletIcon } from '../constants.tsx';

interface SuggestedSource {
  title: string;
  url: string;
  relevance?: string;
}

const BibliographyGenerator: React.FC = () => {
  const [researchTopic, setResearchTopic] = useState<string>('');
  const [suggestedSources, setSuggestedSources] = useState<SuggestedSource[]>([]);
  const [isLoadingSources, setIsLoadingSources] = useState<boolean>(false);
  
  const [urls, setUrls] = useState<string>('');
  const [style, setStyle] = useState<CitationStyle>(CitationStyle.APA7);
  const [references, setReferences] = useState<string>('');
  const [isLoadingFormatting, setIsLoadingFormatting] = useState<boolean>(false);
  
  const [error, setError] = useState<string | null>(null);
  const [copiedReferences, setCopiedReferences] = useState(false);
  const [copiedSuggestions, setCopiedSuggestions] = useState(false);
  const [apiGroundingSources, setApiGroundingSources] = useState<GroundingChunk[]>([]);

  const [rawAiResponse, setRawAiResponse] = useState<string>('');
  const [showRawAiResponse, setShowRawAiResponse] = useState<boolean>(false);

  const parseSuggestedSources = (text: string): SuggestedSource[] => {
    const sources: SuggestedSource[] = [];
    if (!text || text.trim() === "") {
      return sources;
    }

    const lines = text.split('\n');
    let currentSource: Partial<SuggestedSource> = {};
    let accumulatingField: 'title' | 'url' | 'relevance' | null = null;

    const titleKeyword = /^(?:\d+\.\s*-\s*|\d+\.\s*|\*\s*|-\s*)?(?:\*\*)?Judul(?:\*\*)?\s*:\s*/i;
    const urlKeyword = /^(?:\*\*)?(?:URL\/DOI|URL|DOI)(?:\*\*)?\s*:\s*/i;
    const relevanceKeyword = /^(?:\*\*)?Catatan Relevansi(?:\*\*)?\s*:\s*/i;
    const otherKeywords = /^(?:\*\*)?(Penulis|Tahun)(?:\*\*)?\s*:\s*/i; 

    for (const line of lines) {
        const trimmedLine = line.trim();

        if (titleKeyword.test(trimmedLine)) {
            if (currentSource.title && currentSource.url) { 
                 if (currentSource.relevance) currentSource.relevance = currentSource.relevance.trim();
                sources.push(currentSource as SuggestedSource);
            }
            currentSource = { title: trimmedLine.replace(titleKeyword, '').trim() };
            accumulatingField = 'title';
        } else if (urlKeyword.test(trimmedLine) && currentSource.title) {
            let urlValue = trimmedLine.replace(urlKeyword, '').trim();
            const markdownLinkMatch = urlValue.match(/\[.*?\]\((https?:\/\/[^\s\)]+)\)/);
            if (markdownLinkMatch) {
                urlValue = markdownLinkMatch[1];
            }
            currentSource.url = urlValue;
            accumulatingField = 'url';
        } else if (relevanceKeyword.test(trimmedLine) && currentSource.title && currentSource.url) {
            currentSource.relevance = trimmedLine.replace(relevanceKeyword, '').trim();
            accumulatingField = 'relevance';
        } else if (accumulatingField === 'relevance' && currentSource.relevance && !otherKeywords.test(trimmedLine) && !titleKeyword.test(trimmedLine) && trimmedLine) {
            currentSource.relevance += " " + trimmedLine;
        } else if (accumulatingField && currentSource.title && !otherKeywords.test(trimmedLine) && !titleKeyword.test(trimmedLine) && trimmedLine) {
            if (accumulatingField === 'title' && currentSource.title) currentSource.title += " " + trimmedLine;
        } else {
            accumulatingField = null;
        }
    }

    if (currentSource.title && currentSource.url) {
        if (currentSource.relevance) currentSource.relevance = currentSource.relevance.trim();
        sources.push(currentSource as SuggestedSource);
    }
    
    return sources;
  };
  
  const handleSuggestSources = useCallback(async () => {
    if (!researchTopic.trim()) {
      setError("Masukkan topik penelitian untuk mendapatkan saran sumber.");
      return;
    }
    setIsLoadingSources(true);
    setError(null);
    setSuggestedSources([]);
    setApiGroundingSources([]);
    setRawAiResponse('');
    setShowRawAiResponse(false);
    try {
      const response: GeminiResponse = await suggestRelevantSources(researchTopic);
      setRawAiResponse(response.text); 
      
      if (response.text.startsWith("Error:")) {
        setError(response.text);
      } else {
        const parsed = parseSuggestedSources(response.text);
        if (parsed.length === 0 && response.text.trim() !== "" && !response.text.startsWith("Error:")) {
            setError("Adios memberikan respons, tetapi tidak ada sumber yang dapat dikenali dari formatnya. Coba periksa 'Respons Mentah Adios' di bawah atau coba lagi.");
        } else if (parsed.length === 0 && !response.text.startsWith("Error:")) {
            setError("Adios tidak menemukan sumber yang relevan untuk topik ini, atau format respons tidak dikenali. Coba periksa 'Respons Mentah Adios' jika ada output.");
        } else {
            setSuggestedSources(parsed);
        }
      }
      if (response.candidates && response.candidates[0]?.groundingMetadata?.groundingChunks) {
        setApiGroundingSources(response.candidates[0].groundingMetadata.groundingChunks);
      }
    } catch (e: any) {
      setError(e.message || "Gagal mendapatkan saran sumber dari Adios.");
    } finally {
      setIsLoadingSources(false);
    }
  }, [researchTopic]);

  const handleAddSuggestedUrlToManualInput = (url: string) => {
    setUrls(prevUrls => prevUrls ? `${prevUrls}\n${url}` : url);
  };

  const handleGenerateReferences = useCallback(async () => {
    if (!urls.trim()) {
      setError("Masukkan setidaknya satu URL untuk diformat.");
      return;
    }
    setIsLoadingFormatting(true);
    setError(null);
    setReferences('');
    
    const urlArray = urls.split('\n').filter(url => url.trim() !== '');
    try {
      const response: GeminiResponse = await formatReferences(urlArray, style);
       if (response.text.startsWith("Error:")) {
        setError(response.text);
      } else {
        setReferences(response.text);
      }
    } catch (e: any) {
      setError(e.message || "Gagal menghasilkan daftar pustaka.");
    } finally {
      setIsLoadingFormatting(false);
    }
  }, [urls, style]);

  const handleCopyReferences = () => {
    if (references) {
      navigator.clipboard.writeText(references);
      setCopiedReferences(true);
      setTimeout(() => setCopiedReferences(false), 2000);
    }
  };

  const handleCopySuggestions = () => {
    if (suggestedSources.length > 0) {
      const textToCopy = suggestedSources.map(s => `Judul: ${s.title}\nURL: ${s.url}\nRelevansi: ${s.relevance || 'N/A'}`).join('\n\n');
      navigator.clipboard.writeText(textToCopy);
      setCopiedSuggestions(true);
      setTimeout(() => setCopiedSuggestions(false), 2000);
    }
  };

  return (
    <SectionCard
      title="Generator Daftar Pustaka Cerdas"
      description="Adios dapat membantu Anda menemukan sumber inspirasi berdasarkan topik, atau langsung memformat URL yang Anda masukkan ke berbagai gaya sitasi."
    >
      <div className="space-y-6">
        {/* Tahap 1: Saran Sumber (Opsional) */}
        <div className="p-4 border border-sky-300 rounded-lg bg-sky-50">
          <h4 className="text-md font-semibold text-sky-700 mb-2">Langkah 1 (Opsional): Dapatkan Saran Sumber dari Adios</h4>
          <div>
            <label htmlFor="researchTopic" className="block text-sm font-medium text-gray-700 mb-1">
              Masukkan Topik Penelitian Anda:
            </label>
            <textarea
              id="researchTopic"
              value={researchTopic}
              onChange={(e) => setResearchTopic(e.target.value)}
              rows={2}
              className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-sky-500 focus:border-sky-500 bg-white text-gray-900"
              placeholder="Contoh: Dampak Kecerdasan Buatan pada Pasar Kerja Masa Depan"
              disabled={isLoadingSources || isLoadingFormatting}
            />
          </div>
          <button
            onClick={handleSuggestSources}
            disabled={isLoadingSources || isLoadingFormatting || !researchTopic.trim()}
            className="mt-2 w-full bg-sky-500 hover:bg-sky-600 text-white font-semibold py-2.5 px-4 rounded-lg shadow-md disabled:opacity-50 flex items-center justify-center transition-colors"
          >
            {isLoadingSources ? <LoadingSpinner /> : 'Cari Sumber Inspirasi Relevan'}
          </button>
          
          {rawAiResponse && !isLoadingSources && (
            <div className="mt-3">
              <button
                onClick={() => setShowRawAiResponse(!showRawAiResponse)}
                className="text-xs text-sky-600 hover:text-sky-800 underline focus:outline-none"
                aria-expanded={showRawAiResponse}
                aria-controls="raw-ai-response-biblio"
              >
                {showRawAiResponse ? 'Sembunyikan' : 'Lihat'} Respons Mentah Adios (untuk Debug)
              </button>
              {showRawAiResponse && (
                <pre id="raw-ai-response-biblio" className="mt-2 text-xs leading-relaxed whitespace-pre-wrap p-3 rounded-lg bg-gray-800 text-gray-200 max-h-[200px] overflow-y-auto">
                  {rawAiResponse}
                </pre>
              )}
            </div>
          )}

          {suggestedSources.length > 0 && !error && (
            <div className="mt-4 p-4 border border-gray-200 rounded-lg bg-white">
              <div className="flex justify-between items-center mb-2">
                <h5 className="text-sm font-semibold text-gray-700">Sumber yang Disarankan Adios:</h5>
                <button
                    onClick={handleCopySuggestions}
                    className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-md text-xs flex items-center transition-colors"
                    title="Salin Semua Saran ke Clipboard"
                    aria-label="Salin Semua Saran Sumber"
                >
                    {copiedSuggestions ? <CheckIcon className="w-4 h-4 mr-1 text-green-500" /> : <ClipboardIcon className="w-4 h-4 mr-1" />}
                    {copiedSuggestions ? 'Tersalin!' : 'Salin Semua Saran'}
                </button>
              </div>
              <ul className="space-y-3 max-h-72 overflow-y-auto pr-2">
                {suggestedSources.map((source, index) => (
                  <li key={index} className="p-3 border border-gray-200 rounded-lg bg-gray-50 text-xs shadow-sm">
                    <p className="font-medium text-gray-800 mb-0.5">{source.title}</p>
                    <a href={source.url} target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline break-all block mb-1">{source.url}</a>
                    {source.relevance && <p className="text-gray-600 mt-1 text-xs"><strong>Relevansi:</strong> {source.relevance}</p>}
                    <button 
                      onClick={() => handleAddSuggestedUrlToManualInput(source.url)}
                      className="mt-2 text-xs bg-sky-100 hover:bg-sky-200 text-sky-700 px-2 py-1 rounded-md transition-colors"
                    >
                      + Tambahkan ke Input URL Manual
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {apiGroundingSources.length > 0 && !error && ( 
             <div className="mt-4">
                <h5 className="text-sm font-semibold text-gray-600 mb-1">Sumber Informasi yang Digunakan Adios (Google Search):</h5>
                <ul className="list-disc list-inside text-xs text-gray-500">
                {apiGroundingSources.map((source, index) => (
                    <li key={index}>
                    <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline">
                        {source.web.title || source.web.uri}
                    </a>
                    </li>
                ))}
                </ul>
            </div>
           )}
        </div>

        {/* Tahap 2: Format Referensi Manual */}
        <div className="p-4 border border-indigo-300 rounded-lg bg-indigo-50">
          <h4 className="text-md font-semibold text-indigo-700 mb-2">Langkah 2: Format URL ke Daftar Pustaka</h4>
          <div>
            <label htmlFor="urls" className="block text-sm font-medium text-gray-700 mb-1">
              URL Sumber (satu per baris):
            </label>
            <textarea
              id="urls"
              value={urls}
              onChange={(e) => setUrls(e.target.value)}
              rows={5}
              className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
              placeholder="https://contoh.com/artikel1&#10;https://jurnal.org/paper2&#10;DOI: 10.xxxx/j.pon.xxxx"
              disabled={isLoadingFormatting || isLoadingSources}
            />
          </div>
          <div className="mt-3">
            <label htmlFor="citationStyle" className="block text-sm font-medium text-gray-700 mb-1">
              Gaya Sitasi:
            </label>
            <select
              id="citationStyle"
              value={style}
              onChange={(e) => setStyle(e.target.value as CitationStyle)}
              className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
              disabled={isLoadingFormatting || isLoadingSources}
            >
              {Object.values(CitationStyle).map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
          <button
            onClick={handleGenerateReferences}
            disabled={isLoadingFormatting || isLoadingSources || !urls.trim()}
            className="mt-3 w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-4 rounded-lg shadow-md disabled:opacity-50 flex items-center justify-center transition-colors"
          >
            {isLoadingFormatting ? <LoadingSpinner /> : (
                <>
                <ListBulletIcon className="w-5 h-5 mr-2"/>
                Format Daftar Pustaka
                </>
            )}
          </button>
        </div>
        
        {error && <p role="alert" aria-live="assertive" className="text-sm text-red-600 bg-red-100 p-3 rounded-lg border border-red-200 my-4">{error}</p>}

        {references && (
          <div className="mt-6">
            <h4 className="text-md font-semibold text-gray-700 mb-2">Hasil Daftar Pustaka yang Diformat:</h4>
            <div className="relative">
                <button
                onClick={handleCopyReferences}
                className="absolute top-2 right-2 bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-md text-xs flex items-center transition-colors"
                title="Salin Daftar Pustaka ke Clipboard"
                aria-label="Salin Daftar Pustaka"
                >
                {copiedReferences ? <CheckIcon className="w-4 h-4 mr-1 text-green-500" /> : <ClipboardIcon className="w-4 h-4 mr-1" />}
                {copiedReferences ? 'Tersalin!' : 'Salin'}
                </button>
                <pre className="text-sm leading-relaxed whitespace-pre-wrap p-4 rounded-lg max-h-[400px] overflow-y-auto">
                    {references}
                </pre>
            </div>
             <p className="text-xs text-gray-500 mt-2">
              <strong>Catatan Adios:</strong> Selalu verifikasi hasil format dengan panduan sitasi resmi. Adios mungkin memerlukan URL yang sangat spesifik atau DOI untuk hasil terbaik.
            </p>
          </div>
        )}
      </div>
    </SectionCard>
  );
};

export default BibliographyGenerator;