
import React, { useState, useCallback } from 'react';
import { getVizRecommendation } from '../services/geminiService.ts';
import SectionCard from './SectionCard.tsx';
import LoadingSpinner from './LoadingSpinner.tsx';
import { ClipboardIcon, CheckIcon, ChartBarIcon } from '../constants.tsx';
import { GeminiResponse, VizRecommendationResponse, ParsedJsonResponse, VizRecommendationItem } from '../types.ts';

// Utility function to parse JSON and handle markdown fences
const parseJsonFromAiResponse = <T,>(responseText: string): ParsedJsonResponse<T> => {
  let jsonStr = responseText.trim();
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
  const match = jsonStr.match(fenceRegex);
  if (match && match[2]) {
    jsonStr = match[2].trim();
  }
  try {
    return JSON.parse(jsonStr) as T;
  } catch (e) {
    console.error("Failed to parse JSON response:", e, "Raw text:", responseText);
    return { error: `Gagal mem-parse JSON dari Adios: ${e instanceof Error ? e.message : String(e)}`, rawText: responseText };
  }
};

const DataVizRecommender: React.FC = () => {
  const [dataDescription, setDataDescription] = useState<string>('');
  const [researchQuestion, setResearchQuestion] = useState<string>('');
  const [recommendation, setRecommendation] = useState<string>(''); // Stores formatted string or raw text on error
  const [parsedRecommendation, setParsedRecommendation] = useState<VizRecommendationResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [rawResponseOnError, setRawResponseOnError] = useState<string>('');
  const [copied, setCopied] = React.useState(false);

  const formatRecommendationForDisplay = (parsedData: VizRecommendationResponse): string => {
    let displayText = "Rekomendasi Visualisasi dari Adios:\n\n";
    parsedData.recommendations.forEach((rec, index) => {
      displayText += `Rekomendasi ${index + 1}:\n`;
      displayText += `  Jenis Grafik: ${rec.type}\n`;
      displayText += `  Alasan Pemilihan: ${rec.reason}\n`;
      if (rec.example_representation) {
        displayText += `  Contoh Representasi/Deskripsi:\n    ${rec.example_representation.replace(/\n/g, '\n    ')}\n`;
      }
      if (rec.axes_placeholders) {
        displayText += `  Placeholder Sumbu X: ${rec.axes_placeholders.x_axis}\n`;
        displayText += `  Placeholder Sumbu Y: ${rec.axes_placeholders.y_axis}\n`;
      }
      if (rec.suggested_title) {
        displayText += `  Saran Judul Grafik: ${rec.suggested_title}\n`;
      }
      displayText += "\n";
    });
    return displayText;
  };


  const handleGetRecommendation = useCallback(async () => {
    if (!dataDescription.trim()) {
      setError("Masukkan deskripsi data Anda terlebih dahulu.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setRecommendation('');
    setParsedRecommendation(null);
    setRawResponseOnError('');

    try {
      const response: GeminiResponse = await getVizRecommendation(dataDescription, researchQuestion);
      if (response.text.startsWith("Error:")) {
        setError(response.text);
      } else {
        const parsedResult = parseJsonFromAiResponse<VizRecommendationResponse>(response.text);
        if ('error' in parsedResult) {
          setError(`${parsedResult.error}. Menampilkan respons mentah dari Adios.`);
          setRawResponseOnError(parsedResult.rawText);
          setRecommendation(parsedResult.rawText); // Show raw text on parse error
        } else {
          setParsedRecommendation(parsedResult);
          setRecommendation(formatRecommendationForDisplay(parsedResult));
        }
      }
    } catch (e: any) {
      setError(e.message || "Gagal mendapatkan rekomendasi visualisasi data dari Adios.");
    } finally {
      setIsLoading(false);
    }
  }, [dataDescription, researchQuestion]);

  const handleCopy = () => {
    if (recommendation) { // Always copy the 'recommendation' string which is either formatted or raw error
      navigator.clipboard.writeText(recommendation);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const renderRecommendationContent = () => {
    if (parsedRecommendation && !rawResponseOnError) {
      return parsedRecommendation.recommendations.map((rec, index) => (
        <div key={index} className="mb-4 p-3 border border-gray-200 rounded-md bg-gray-50">
          <h5 className="text-sm font-semibold text-indigo-700">Rekomendasi {index + 1}: {rec.type}</h5>
          <p className="text-xs mt-1"><strong>Alasan:</strong> {rec.reason}</p>
          {rec.example_representation && <pre className="text-xs mt-1 bg-gray-100 p-2 rounded overflow-x-auto"><strong>Contoh/Deskripsi:</strong><br/>{rec.example_representation}</pre>}
          {rec.axes_placeholders && (
            <p className="text-xs mt-1">
              <strong>Sumbu X (placeholder):</strong> {rec.axes_placeholders.x_axis}<br/>
              <strong>Sumbu Y (placeholder):</strong> {rec.axes_placeholders.y_axis}
            </p>
          )}
          {rec.suggested_title && <p className="text-xs mt-1"><strong>Saran Judul:</strong> {rec.suggested_title}</p>}
        </div>
      ));
    }
    // If there's a raw response due to parsing error, or if recommendation is just text
    return <pre className="text-sm leading-relaxed whitespace-pre-wrap p-4 rounded-lg max-h-[600px] overflow-y-auto">{recommendation}</pre>;
  };


  return (
    <SectionCard
      title="Rekomendasi Visualisasi Data Cerdas (Adios)"
      description="Deskripsikan data Anda dan (opsional) pertanyaan utama yang ingin dijawab. Adios akan merekomendasikan jenis grafik (dalam format JSON), menjelaskan alasannya, dan memberikan contoh representasi."
    >
      <div className="space-y-4">
        <div>
          <label htmlFor="dataDescription" className="block text-sm font-medium text-gray-700 mb-1">
            Deskripsi Data Anda (Wajib):
          </label>
          <textarea
            id="dataDescription"
            value={dataDescription}
            onChange={(e) => setDataDescription(e.target.value)}
            rows={4}
            className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
            placeholder="Contoh: Saya memiliki data survei kepuasan pengguna terhadap 5 fitur produk (skala Likert 1-5) dari 100 responden, dengan data demografi usia dan gender."
            disabled={isLoading}
          />
        </div>
        <div>
          <label htmlFor="researchQuestion" className="block text-sm font-medium text-gray-700 mb-1">
            Pertanyaan Utama yang Ingin Dijawab dengan Visualisasi (Opsional):
          </label>
          <input
            type="text"
            id="researchQuestion"
            value={researchQuestion}
            onChange={(e) => setResearchQuestion(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
            placeholder="Contoh: Fitur produk mana yang memiliki tingkat kepuasan tertinggi?"
            disabled={isLoading}
          />
        </div>
        <button
          onClick={handleGetRecommendation}
          disabled={isLoading || !dataDescription.trim()}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-4 rounded-lg shadow-md disabled:opacity-50 flex items-center justify-center transition-colors"
        >
          {isLoading ? <LoadingSpinner /> : (
            <>
              <ChartBarIcon className="w-5 h-5 mr-2" />
              Dapatkan Rekomendasi Grafik dari Adios
            </>
          )}
        </button>
        {error && !rawResponseOnError && <p role="alert" aria-live="assertive" className="text-sm text-red-600 bg-red-100 p-3 rounded-lg border border-red-200">{error}</p>}
        {error && rawResponseOnError && (
             <div role="alert" aria-live="assertive" className="text-sm text-orange-700 bg-orange-100 p-3 rounded-lg border border-orange-200">
                {error}
             </div>
        )}

        {recommendation && (
          <div className="mt-6">
            <div className="flex justify-between items-center mb-2">
                <h4 className="text-md font-semibold text-gray-700">
                    {rawResponseOnError ? "Respons Mentah dari Adios (Gagal Parse JSON):" : "Rekomendasi Visualisasi dari Adios:"}
                </h4>
                <button
                    onClick={handleCopy}
                    className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-md text-xs flex items-center transition-colors"
                    title="Salin Rekomendasi ke Clipboard"
                    aria-label="Salin rekomendasi visualisasi"
                >
                    {copied ? <CheckIcon className="w-4 h-4 mr-1 text-green-500" /> : <ClipboardIcon className="w-4 h-4 mr-1" />}
                    {copied ? 'Tersalin!' : 'Salin'}
                </button>
            </div>
            <div className="bg-white p-px rounded-lg border border-gray-200 shadow-sm max-h-[600px] overflow-y-auto">
                 {renderRecommendationContent()}
            </div>
            <p className="text-xs text-gray-500 mt-2">
              <strong>Tips Adios:</strong> Gunakan rekomendasi ini sebagai panduan. Pilihan visualisasi terbaik juga bergantung pada audiens dan cerita yang ingin Anda sampaikan.
            </p>
          </div>
        )}
      </div>
    </SectionCard>
  );
};

export default DataVizRecommender;
