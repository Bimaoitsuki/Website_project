
import React, { useState, useEffect, useCallback } from 'react';
import SectionCard from './SectionCard.tsx';
import {
    APP_TITLE,
    FEATURES_MENU,
    CheckCircleIcon,
    XCircleIcon,
    BeakerIcon,
    ComputerDesktopIcon,
    BoltIcon,
    InformationCircleIcon,
    EyeIcon, 
    EyeSlashIcon,
    ChevronDownIcon,
    ChevronUpIcon,
} from '../constants.tsx';
import { Feature } from '../types.ts';
import LoadingSpinner from './LoadingSpinner.tsx';

interface FAQItemProps {
  question: string;
  children: React.ReactNode;
}

const FAQItem: React.FC<FAQItemProps> = ({ question, children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const id = `faq-${question.replace(/\s+/g, '-').toLowerCase()}`;

  return (
    <details 
        className="group border border-gray-200 rounded-lg overflow-hidden"
        onToggle={(e) => setIsOpen((e.target as HTMLDetailsElement).open)}
    >
      <summary 
        className="flex justify-between items-center p-4 cursor-pointer bg-gray-50 hover:bg-gray-100 transition-colors"
        aria-expanded={isOpen}
        aria-controls={id}
      >
        <h5 className="text-sm font-medium text-gray-700">{question}</h5>
        {isOpen ? <ChevronUpIcon className="w-5 h-5 text-indigo-600" /> : <ChevronDownIcon className="w-5 h-5 text-gray-500" />}
      </summary>
      <div id={id} className="p-4 text-sm text-gray-600 bg-white leading-relaxed">
        {children}
      </div>
    </details>
  );
};


const InformationPage: React.FC = () => {
  const qrCodeUrl = "https://raw.githubusercontent.com/Bimaoitsuki/BimaOutsuki/main/IMG-20250527-WA0000.jpg";
  const teamPhotoUrl = "https://raw.githubusercontent.com/Bimaoitsuki/BimaOutsuki/main/IMG-20250401-WA0019.jpg";
  const features = FEATURES_MENU.filter(f => f.id !== Feature.INFORMATION);
  const whatsAppNumber = "+6281540892122";

  const [simulatedLatencyResult, setSimulatedLatencyResult] = useState<string>('');
  const [isMeasuringLatency, setIsMeasuringLatency] = useState<boolean>(false);
  const [isWhatsAppVisible, setIsWhatsAppVisible] = useState<boolean>(false);

  const isApiKeyActive = process.env.API_KEY && process.env.API_KEY !== "MISSING_API_KEY_PLACEHOLDER" && process.env.API_KEY.length > 10;

  const handleSimulateLatencyCheck = useCallback(async () => {
    setIsMeasuringLatency(true);
    setSimulatedLatencyResult(''); 
    await new Promise(resolve => setTimeout(resolve, 1200 + Math.random() * 800)); 
    const randomLatency = Math.floor(Math.random() * 250) + 50; 
    setSimulatedLatencyResult(`Latensi Adios (simulasi): ${randomLatency}ms. Respons ${randomLatency < 150 ? 'Sangat Cepat' : (randomLatency < 300 ? 'Cepat' : 'Sedang')}.`);
    setIsMeasuringLatency(false);
  }, []);

  useEffect(() => {
    if (isApiKeyActive) {
      handleSimulateLatencyCheck();
    } else {
      setSimulatedLatencyResult("Simulasi latensi tidak dapat dijalankan: Kunci API tidak aktif atau belum dikonfigurasi.");
      setIsMeasuringLatency(false);
    }
  }, [isApiKeyActive, handleSimulateLatencyCheck]);

  const toggleWhatsAppVisibility = () => {
    setIsWhatsAppVisible(!isWhatsAppVisible);
  };

  return (
    <SectionCard title="Informasi Aplikasi" description={`Detail mengenai ${APP_TITLE} dan status sistem.`}>
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2 flex items-center">
            <ComputerDesktopIcon className="w-6 h-6 mr-2 text-indigo-600" />
            Status Sistem Umum
          </h3>
          <ul className="space-y-1.5 text-sm">
            <li className="flex items-center">
              Kunci API (Google Gemini):
              {isApiKeyActive ? (
                <span className="ml-2 flex items-center text-green-600 font-medium">
                  <CheckCircleIcon className="w-5 h-5 mr-1" /> Aktif & Siap Digunakan
                </span>
              ) : (
                <span className="ml-2 flex items-center text-red-600 font-medium">
                  <XCircleIcon className="w-5 h-5 mr-1" /> Tidak Aktif / Belum Dikonfigurasi
                </span>
              )}
            </li>
             <li className="text-xs text-gray-500 pl-1 mt-0.5">
                (Status ini hanya indikasi. Jika Adios tidak merespons, periksa konsol untuk error API Key.)
            </li>
          </ul>
        </div>

        <div className="p-4 bg-gray-50 rounded-lg border border-gray-200 shadow-sm">
          <h4 className="text-md font-semibold text-gray-700 mb-2 flex items-center">
            <BoltIcon className="w-5 h-5 mr-2 text-indigo-500" />
            Status Ping & Latensi Adios
          </h4>
          {isMeasuringLatency && (
            <div role="status" className="mt-2 flex items-center text-sm text-indigo-600">
              <LoadingSpinner /> <span className="ml-2">Memeriksa koneksi & latensi ke Adios...</span>
            </div>
          )}
          {!isMeasuringLatency && simulatedLatencyResult && (
             <div role="status" aria-live="polite">
                <p className={`text-sm mt-2 p-3 border rounded-md shadow-sm ${isApiKeyActive ? 'bg-teal-50 border-teal-200 text-teal-800' : 'bg-amber-50 border-amber-200 text-amber-800'}`}>
                    {simulatedLatencyResult}
                </p>
             </div>
          )}
        </div>

        <div className="pt-4 border-t border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800 mb-2">Tentang {APP_TITLE}</h3>
          <p className="text-sm text-gray-600 leading-relaxed mb-3">
            <strong>{APP_TITLE}</strong> adalah partner cerdas Anda dalam menaklukkan skripsi! Aplikasi web modern ini menyederhanakan proses penyusunan dengan fitur-fitur unggulan, didukung Adios (Asisten Digital Olah Skripsi) berbasis AI:
          </p>
          <ul className="list-disc list-inside space-y-1.5 text-sm text-gray-600 mb-3 pl-4">
            {features.map(feature => (
                <li key={feature.id}><strong>{feature.name.split(' (')[0]}:</strong> {
                    feature.id === Feature.AI_THESIS_DRAFT_GENERATOR ? "Dari ide awal, formulasikan judul cerdas, hingga hasilkan draf naskah lengkap 5 Bab." :
                    feature.id === Feature.AUTO_FORMATTING ? "Dapatkan rekomendasi presisi untuk tata letak dokumen Anda." :
                    feature.id === Feature.SAMPLE_DOCS ? "Akses contoh konten relevan untuk berbagai bagian skripsi." :
                    feature.id === Feature.BIBLIOGRAPHY ? "Buat daftar pustaka akurat dari URL atau inspirasi topik." :
                    feature.id === Feature.CHECKLIST ? "Sesuaikan checklist final submit dengan jurusan Anda." :
                    feature.id === Feature.PARAPHRASING ? "Bantu jaga orisinalitas tulisan Anda." :
                    feature.id === Feature.LOGIC_ANALYSIS ? "Analisis klaim, dukungan, dan koherensi argumen Anda." :
                    feature.id === Feature.DATA_VIZ ? "Temukan grafik yang paling tepat untuk menyajikan data Anda." :
                    feature.id === Feature.PRESENTATION ? "Siapkan kerangka presentasi yang efektif dan terstruktur." :
                    "Fitur unggulan untuk membantu skripsi Anda."
                }</li>
            ))}
          </ul>
          <p className="text-sm text-gray-600">
            Dengan {APP_TITLE}, proses penyusunan skripsi menjadi lebih terarah, efisien, dan cerdas.
          </p>
          <p className="text-sm text-gray-600 mt-3">
            Total fitur utama yang siap membantu Anda (selain halaman informasi ini): <strong>{features.length} fitur</strong>.
          </p>
           <p className="text-xs text-gray-500 mt-2">
              Jelajahi berbagai fitur melalui menu navigasi untuk memaksimalkan potensi skripsi Anda!
            </p>
        </div>

        <div className="pt-4 border-t border-gray-200">
            <h3 className="text-lg font-semibold text-gray-800 mb-3 flex items-center">
                <InformationCircleIcon className="w-6 h-6 mr-2 text-indigo-600" />
                Bantuan & FAQ (Pertanyaan Umum)
            </h3>
            <div className="space-y-3">
                <FAQItem question={`Bagaimana cara kerja Adios (AI) di ${APP_TITLE}?`}>
                    <p>Adios menggunakan model AI generatif canggih dari Google (Gemini) untuk memahami permintaan Anda dan menghasilkan teks, saran, atau analisis. Untuk beberapa fitur seperti 'Generator Daftar Pustaka', Adios juga dapat menggunakan Google Search untuk mencari informasi relevan.</p>
                    <p className="mt-2">Penting untuk diingat bahwa Adios adalah alat bantu. Output yang dihasilkan AI harus selalu Anda review, validasi, dan sesuaikan dengan kebutuhan, konteks akademik, serta panduan institusi Anda.</p>
                </FAQItem>
                <FAQItem question="Apakah data yang saya masukkan aman?">
                    <p>Aplikasi ini dirancang untuk berjalan di sisi klien (browser Anda) sebanyak mungkin. Interaksi dengan API Google Gemini tunduk pada kebijakan privasi Google. Kami tidak menyimpan data input atau output Anda di server kami secara permanen untuk fitur-fitur inti.</p>
                    <p className="mt-2">Untuk penggunaan API Key, pastikan Anda mengelola API Key Anda dengan aman dan tidak membagikannya. Aplikasi ini mengambil API Key dari variabel lingkungan yang telah dikonfigurasi sebelumnya.</p>
                </FAQItem>
                <FAQItem question="Mengapa terkadang Adios tidak memberikan hasil yang saya harapkan?">
                    <p>Kualitas output AI bergantung pada banyak faktor, termasuk:</p>
                    <ul className="list-disc list-inside pl-4 mt-1">
                        <li><strong>Kejelasan Instruksi (Prompt):</strong> Semakin spesifik dan jelas input atau permintaan Anda, semakin baik hasil yang mungkin didapatkan.</li>
                        <li><strong>Kompleksitas Tugas:</strong> Tugas yang sangat kompleks atau membutuhkan pengetahuan domain yang sangat mendalam mungkin memerlukan iterasi atau penyempurnaan manual.</li>
                        <li><strong>Batasan Model AI:</strong> Model AI memiliki batasan pengetahuan (cut-off date) dan terkadang bisa menghasilkan informasi yang tidak sepenuhnya akurat atau "berhalusinasi". Selalu verifikasi informasi penting.</li>
                    </ul>
                    <p className="mt-2">Jika hasil kurang memuaskan, coba formulasikan ulang permintaan Anda, berikan lebih banyak konteks, atau pecah tugas menjadi bagian-bagian yang lebih kecil.</p>
                </FAQItem>
                 <FAQItem question="Fitur mana yang paling cocok untuk memulai skripsi?">
                    <p>Jika Anda baru memulai, fitur "Generator Naskah Skripsi (Adios)" bisa menjadi titik awal yang baik. Masukkan ide penelitian Anda, dan Adios akan membantu memformulasikan judul serta membuat draf awal skripsi (Daftar Isi + 5 Bab) yang bisa Anda kembangkan.</p>
                    <p className="mt-2">Fitur "Contoh Dokumen" juga berguna untuk melihat contoh bagian-bagian skripsi yang terstruktur.</p>
                </FAQItem>
                <FAQItem question="Bagaimana cara menggunakan API Key dengan benar?">
                  <p>Aplikasi ini mengambil API Key dari variabel lingkungan <code>process.env.API_KEY</code> yang diasumsikan sudah terkonfigurasi di lingkungan tempat aplikasi ini dijalankan. Anda tidak perlu memasukkan API Key secara manual di dalam aplikasi.</p>
                  <p className="mt-2">Jika Anda menjalankan aplikasi ini secara lokal untuk pengembangan, pastikan Anda telah membuat file <code>.env</code> di root proyek dan menambahkan baris <code>API_KEY=kunci_api_anda</code>, lalu restart server pengembangan Anda.</p>
                </FAQItem>
            </div>
        </div>


        <div className="pt-4 border-t border-gray-200">
           <h3 className="text-lg font-semibold text-gray-800 mb-3 flex items-center">
             <BeakerIcon className="w-6 h-6 mr-2 text-indigo-600" />
             Tim Pengembang & Kontak
           </h3>
           <div className="flex flex-col sm:flex-row gap-6 items-start">
              <div className="flex-shrink-0">
                <img
                    src={teamPhotoUrl}
                    alt="Foto Tim Pengembang Bima Outsuki"
                    className="w-40 h-40 sm:w-48 sm:h-48 border-2 border-indigo-200 rounded-full shadow-md hover:shadow-lg transition-shadow object-cover"
                    aria-label="Foto Tim Pengembang"
                />
              </div>
              <div className="text-sm text-gray-600 space-y-2">
                <p>Aplikasi ini dikembangkan oleh:</p>
                <p><strong>Nama:</strong> Bima Outsuki</p>
                <p><strong>Organisasi:</strong> Dari "Tim Pembela Kebenaran"</p>
                <p><strong>Usia:</strong> 20 tahun (terakhir menghitung, sekarang sudah malas menghitung)</p>
                <p className="mt-2">
                  Untuk pertanyaan, masukan, atau dukungan teknis, silakan hubungi via WhatsApp di{' '}
                  <span className="inline-flex items-center align-middle">
                    <strong className="text-indigo-600 mr-1.5">
                      {isWhatsAppVisible ? whatsAppNumber : "••••••••••••"}
                    </strong>
                    <button
                      onClick={toggleWhatsAppVisibility}
                      className="text-indigo-500 hover:text-indigo-700 focus:outline-none p-0.5 rounded-full hover:bg-indigo-100 transition-colors"
                      aria-label={isWhatsAppVisible ? "Sembunyikan nomor WhatsApp" : "Tampilkan nomor WhatsApp"}
                      title={isWhatsAppVisible ? "Sembunyikan nomor WhatsApp" : "Tampilkan nomor WhatsApp"}
                    >
                      {isWhatsAppVisible ? <EyeSlashIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                    </button>
                  </span>.
                </p>
                <p>Jika Anda merasa aplikasi ini bermanfaat dan ingin memberikan dukungan, Anda dapat berdonasi melalui QRIS (mendukung semua bank di Indonesia) dengan memindai QR Code berikut:</p>
                 <img
                    src={qrCodeUrl}
                    alt="QR Code Donasi QRIS Jago Susun"
                    className="w-32 h-32 sm:w-36 sm:h-36 border-2 border-indigo-200 rounded-lg shadow-md hover:shadow-lg transition-shadow mt-1 bg-white"
                    aria-label="Scan untuk Donasi QRIS Jago Susun"
                  />
              </div>
           </div>
        </div>

        <div className="pt-4 border-t border-gray-200 text-center text-xs text-gray-500">
          <p>&copy; {new Date().getFullYear()} {APP_TITLE}. Dibuat dengan ❤️ untuk kemajuan akademik.</p>
        </div>
      </div>
    </SectionCard>
  );
};

export default InformationPage;