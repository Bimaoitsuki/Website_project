
import React from 'react';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex items-center justify-center space-x-2">
      <div className="w-4 h-4 rounded-full animate-pulse bg-indigo-600"></div>
      <div className="w-4 h-4 rounded-full animate-pulse bg-indigo-600 delay-200"></div>
      <div className="w-4 h-4 rounded-full animate-pulse bg-indigo-600 delay-400"></div>
      <span className="ml-2 text-indigo-600">Memproses...</span>
    </div>
  );
};

export default LoadingSpinner;