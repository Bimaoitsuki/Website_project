
import React, { useState, useCallback } from 'react';
import { getLogicAnalysis } from '../services/geminiService.ts';
import SectionCard from './SectionCard.tsx';
import LoadingSpinner from './LoadingSpinner.tsx';
import { ClipboardIcon, CheckIcon, BeakerIcon } from '../constants.tsx';
import { GeminiResponse, LogicAnalysisResponse, ParsedJsonResponse, LogicAnalysisFallacy } from '../types.ts';

// Utility function to parse JSON and handle markdown fences
const parseJsonFromAiResponse = <T,>(responseText: string): ParsedJsonResponse<T> => {
  let jsonStr = responseText.trim();
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
  const match = jsonStr.match(fenceRegex);
  if (match && match[2]) {
    jsonStr = match[2].trim();
  }
  try {
    return JSON.parse(jsonStr) as T;
  } catch (e) {
    console.error("Failed to parse JSON response:", e, "Raw text:", responseText);
    return { error: `Gagal mem-parse JSON dari Adios: ${e instanceof Error ? e.message : String(e)}`, rawText: responseText };
  }
};


const LogicAnalysis: React.FC = () => {
  const [inputText, setInputText] = useState<string>('');
  const [analysisResult, setAnalysisResult] = useState<string>(''); // Stores formatted string or raw text on error
  const [parsedAnalysis, setParsedAnalysis] = useState<LogicAnalysisResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [rawResponseOnError, setRawResponseOnError] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const formatAnalysisForDisplay = (parsedData: LogicAnalysisResponse): string => {
    let displayText = "Hasil Analisis dari Adios LogicSense:\n\n";
    
    displayText += "**1. Identifikasi Klaim Utama:**\n";
    if (parsedData.identified_claims && parsedData.identified_claims.length > 0) {
      parsedData.identified_claims.forEach(claim => {
        displayText += `- ${claim}\n`;
      });
    } else {
      displayText += "- Tidak ada klaim utama yang teridentifikasi secara jelas.\n";
    }
    displayText += "\n";

    displayText += "**2. Evaluasi Kekuatan Dukungan/Bukti:**\n";
    if (parsedData.support_evaluation) {
      displayText += `- Penilaian: ${parsedData.support_evaluation.assessment}\n`;
      if (parsedData.support_evaluation.evidence_type) {
        displayText += `- Jenis Bukti: ${parsedData.support_evaluation.evidence_type}\n`;
      }
      if (parsedData.support_evaluation.suggestions_for_improvement) {
        displayText += `- Saran Perbaikan Dukungan: ${parsedData.support_evaluation.suggestions_for_improvement}\n`;
      }
    } else {
      displayText += "- Evaluasi dukungan tidak tersedia.\n";
    }
    displayText += "\n";
    
    displayText += "**3. Deteksi Potensi Kesalahan Logika (Logical Fallacies):**\n";
    if (typeof parsedData.logical_fallacies === 'string') {
        displayText += `- ${parsedData.logical_fallacies}\n`;
    } else if (parsedData.logical_fallacies && parsedData.logical_fallacies.length > 0) {
      parsedData.logical_fallacies.forEach(fallacy => {
        displayText += `- ${fallacy.fallacy_name}:\n`;
        displayText += `  - Penjelasan: ${fallacy.explanation}\n`;
        displayText += `  - Kutipan Teks: "${fallacy.quote_from_text}"\n`;
      });
    } else {
      displayText += "- Tidak ada kesalahan logika yang terdeteksi secara signifikan.\n";
    }
    displayText += "\n";

    displayText += "**4. Analisis Koherensi dan Alur Pikiran:**\n";
    if (parsedData.coherence_and_flow) {
      displayText += `- Penilaian: ${parsedData.coherence_and_flow.assessment}\n`;
      if (parsedData.coherence_and_flow.problem_areas && parsedData.coherence_and_flow.problem_areas.length > 0) {
        displayText += `- Area Bermasalah Teridentifikasi:\n`;
        parsedData.coherence_and_flow.problem_areas.forEach(area => {
            displayText += `  - ${area}\n`;
        });
      }
    } else {
      displayText += "- Analisis koherensi tidak tersedia.\n";
    }
    displayText += "\n";

    displayText += "**5. Saran Peningkatan Struktur Argumen:**\n";
    if (parsedData.improvement_suggestions && parsedData.improvement_suggestions.length > 0) {
      parsedData.improvement_suggestions.forEach(suggestion => {
        displayText += `- ${suggestion}\n`;
      });
    } else {
      displayText += "- Tidak ada saran peningkatan spesifik saat ini.\n";
    }
    
    return displayText;
  };


  const handleAnalyzeText = useCallback(async () => {
    if (!inputText.trim()) {
      setError("Masukkan teks yang ingin dianalisis terlebih dahulu.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setAnalysisResult('');
    setParsedAnalysis(null);
    setRawResponseOnError('');

    try {
      const response: GeminiResponse = await getLogicAnalysis(inputText);
      if (response.text.startsWith("Error:")) {
        setError(response.text);
      } else {
        const parsedResult = parseJsonFromAiResponse<LogicAnalysisResponse>(response.text);
        if ('error' in parsedResult) {
          setError(`${parsedResult.error}. Menampilkan respons mentah dari Adios.`);
          setRawResponseOnError(parsedResult.rawText);
          setAnalysisResult(parsedResult.rawText); // Show raw text on parse error
        } else {
          setParsedAnalysis(parsedResult);
          setAnalysisResult(formatAnalysisForDisplay(parsedResult));
        }
      }
    } catch (e: any) {
      setError(e.message || "Gagal mendapatkan analisis argumen dari Adios.");
    } finally {
      setIsLoading(false);
    }
  }, [inputText]);

  const handleCopy = () => {
    if (analysisResult) {
      navigator.clipboard.writeText(analysisResult);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };
  
  const renderAnalysisContent = () => {
    if (parsedAnalysis && !rawResponseOnError) {
        return (
            <div>
                <div className="mb-3 p-2 border-b border-gray-200">
                    <h5 className="text-sm font-semibold text-indigo-700">1. Identifikasi Klaim Utama:</h5>
                    {parsedAnalysis.identified_claims && parsedAnalysis.identified_claims.length > 0 ? (
                        <ul className="list-disc list-inside pl-4 text-xs">
                            {parsedAnalysis.identified_claims.map((claim, i) => <li key={i}>{claim}</li>)}
                        </ul>
                    ) : <p className="text-xs text-gray-500 pl-4">Tidak ada klaim utama yang teridentifikasi.</p>}
                </div>

                <div className="mb-3 p-2 border-b border-gray-200">
                    <h5 className="text-sm font-semibold text-indigo-700">2. Evaluasi Kekuatan Dukungan/Bukti:</h5>
                    <p className="text-xs"><strong>Penilaian:</strong> {parsedAnalysis.support_evaluation?.assessment || 'N/A'}</p>
                    {parsedAnalysis.support_evaluation?.evidence_type && <p className="text-xs"><strong>Jenis Bukti:</strong> {parsedAnalysis.support_evaluation.evidence_type}</p>}
                    {parsedAnalysis.support_evaluation?.suggestions_for_improvement && <p className="text-xs"><strong>Saran Perbaikan:</strong> {parsedAnalysis.support_evaluation.suggestions_for_improvement}</p>}
                </div>

                <div className="mb-3 p-2 border-b border-gray-200">
                    <h5 className="text-sm font-semibold text-indigo-700">3. Deteksi Potensi Kesalahan Logika:</h5>
                    {typeof parsedAnalysis.logical_fallacies === 'string' ? (
                        <p className="text-xs pl-4">{parsedAnalysis.logical_fallacies}</p>
                    ) : parsedAnalysis.logical_fallacies && parsedAnalysis.logical_fallacies.length > 0 ? (
                        parsedAnalysis.logical_fallacies.map((fallacy, i) => (
                            <div key={i} className="text-xs pl-4 mb-1">
                                <p><strong>{fallacy.fallacy_name}:</strong> {fallacy.explanation}</p>
                                <p className="italic">Kutipan: "{fallacy.quote_from_text}"</p>
                            </div>
                        ))
                    ) : <p className="text-xs text-gray-500 pl-4">Tidak ada kesalahan logika signifikan yang terdeteksi.</p>}
                </div>
                
                <div className="mb-3 p-2 border-b border-gray-200">
                    <h5 className="text-sm font-semibold text-indigo-700">4. Analisis Koherensi dan Alur Pikiran:</h5>
                    <p className="text-xs"><strong>Penilaian:</strong> {parsedAnalysis.coherence_and_flow?.assessment || 'N/A'}</p>
                    {parsedAnalysis.coherence_and_flow?.problem_areas && parsedAnalysis.coherence_and_flow.problem_areas.length > 0 && (
                        <div>
                            <p className="text-xs"><strong>Area Bermasalah:</strong></p>
                            <ul className="list-disc list-inside pl-6 text-xs">
                                {parsedAnalysis.coherence_and_flow.problem_areas.map((area, i) => <li key={i}>{area}</li>)}
                            </ul>
                        </div>
                    )}
                </div>

                <div>
                    <h5 className="text-sm font-semibold text-indigo-700">5. Saran Peningkatan Struktur Argumen:</h5>
                    {parsedAnalysis.improvement_suggestions && parsedAnalysis.improvement_suggestions.length > 0 ? (
                        <ul className="list-disc list-inside pl-4 text-xs">
                            {parsedAnalysis.improvement_suggestions.map((suggestion, i) => <li key={i}>{suggestion}</li>)}
                        </ul>
                    ) : <p className="text-xs text-gray-500 pl-4">Tidak ada saran peningkatan spesifik.</p>}
                </div>
            </div>
        );
    }
    return <pre className="text-sm leading-relaxed whitespace-pre-wrap p-4 rounded-lg max-h-[600px] overflow-y-auto">{analysisResult}</pre>;
  };


  return (
    <SectionCard
      title="Analisis Argumen & Koherensi Logis (Adios LogicSense)"
      description="Masukkan bagian teks skripsi Anda. Adios akan menganalisis klaim, dukungan, potensi kesalahan logika, koherensi, dan memberikan saran (dalam format JSON)."
    >
      <div className="space-y-4">
        <div>
          <label htmlFor="inputTextLogic" className="block text-sm font-medium text-gray-700 mb-1">
            Teks untuk Dianalisis:
          </label>
          <textarea
            id="inputTextLogic"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            rows={10}
            className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
            placeholder="Tempelkan atau ketik bagian teks skripsi Anda di sini..."
            disabled={isLoading}
            aria-label="Teks untuk dianalisis"
          />
        </div>
        <button
          onClick={handleAnalyzeText}
          disabled={isLoading || !inputText.trim()}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-4 rounded-lg shadow-md disabled:opacity-50 flex items-center justify-center transition-colors"
          aria-busy={isLoading}
        >
          {isLoading ? <LoadingSpinner /> : (
            <>
              <BeakerIcon className="w-5 h-5 mr-2" />
              Mulai Analisis Adios LogicSense
            </>
          )}
        </button>

        {error && !rawResponseOnError && <p role="alert" aria-live="assertive" className="text-sm text-red-600 bg-red-100 p-3 rounded-lg border border-red-200">{error}</p>}
        {error && rawResponseOnError && (
             <div role="alert" aria-live="assertive" className="text-sm text-orange-700 bg-orange-100 p-3 rounded-lg border border-orange-200">
                {error}
             </div>
        )}
        
        {analysisResult && (
          <div className="mt-6">
            <div className="flex justify-between items-center mb-2">
                <h4 className="text-md font-semibold text-gray-700">
                    {rawResponseOnError ? "Respons Mentah dari Adios (Gagal Parse JSON):" : "Hasil Analisis dari Adios LogicSense:"}
                </h4>
                <button
                    onClick={handleCopy}
                    className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-md text-xs flex items-center transition-colors"
                    title="Salin Hasil Analisis ke Clipboard"
                    aria-label="Salin Hasil Analisis ke Clipboard"
                >
                    {copied ? <CheckIcon className="w-4 h-4 mr-1 text-green-500" /> : <ClipboardIcon className="w-4 h-4 mr-1" />}
                    {copied ? 'Tersalin!' : 'Salin'}
                </button>
            </div>
            <div className="bg-white p-px rounded-lg border border-gray-200 shadow-sm max-h-[600px] overflow-y-auto">
              {renderAnalysisContent()}
            </div>
            <p className="text-xs text-gray-500 mt-3">
              <strong>Catatan Adios:</strong> Gunakan analisis ini sebagai panduan untuk refleksi dan perbaikan. Keputusan akhir dan pemikiran kritis tetap ada pada Anda.
            </p>
          </div>
        )}
      </div>
    </SectionCard>
  );
};

export default LogicAnalysis;
