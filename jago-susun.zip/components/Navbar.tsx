
import React, { useState } from 'react';
import { Feature } from '../types.ts'; 
import { FEATURES_MENU, APP_TITLE, ClockIcon } from '../constants.ts'; 
// SunIcon and MoonIcon imports removed

interface NavbarProps {
  activeFeature: Feature;
  setActiveFeature: (feature: Feature) => void;
  sessionDuration: string;
  // currentTheme and toggleTheme props removed
}

const Navbar: React.FC<NavbarProps> = ({ activeFeature, setActiveFeature, sessionDuration }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // ThemeToggleButton component removed

  return (
    <>
      {/* Mobile Navbar */}
      <div className="md:hidden bg-gray-800 p-4 flex justify-between items-center sticky top-0 z-20 shadow-md">
        <h1 className="text-xl font-bold text-indigo-400">{APP_TITLE}</h1>
        <div className="flex items-center">
          {/* ThemeToggleButton removed from here */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="ml-2 text-gray-300 hover:text-white focus:outline-none"
            aria-label="Toggle menu"
            aria-expanded={isMobileMenuOpen}
            aria-controls="mobile-menu-content"
          >
            {isMobileMenuOpen ? (
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-6 h-6">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-6 h-6">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
              </svg>
            )}
          </button>
        </div>
      </div>
      {isMobileMenuOpen && (
        <div id="mobile-menu-content" className="md:hidden bg-gray-800 py-2 absolute w-full z-10 shadow-lg">
          {FEATURES_MENU.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveFeature(item.id);
                setIsMobileMenuOpen(false);
              }}
              className={`w-full flex items-center px-4 py-3 text-sm transition-colors duration-150 ease-in-out
                ${activeFeature === item.id 
                  ? 'bg-indigo-600 text-white' 
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'}`}
            >
              {item.icon}
              {item.name}
            </button>
          ))}
           <div className="px-4 py-3 text-xs text-gray-500 border-t border-gray-700">
            <p>&copy; {new Date().getFullYear()} {APP_TITLE}</p>
            <p>Didukung oleh Adios (AI)</p>
            <div className="flex items-center justify-center mt-1">
              <ClockIcon className="w-3 h-3 mr-1" />
              <span>Sesi: {sessionDuration}</span>
            </div>
          </div>
        </div>
      )}

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex md:flex-col md:w-72 bg-gray-800 text-gray-300 p-6 space-y-6 sticky top-0 h-screen overflow-y-auto">
        <div className="text-center mb-4">
          <div className="flex justify-center items-center"> {/* Adjusted to center as toggle is removed */}
            <h1 className="text-2xl font-bold text-indigo-400">{APP_TITLE}</h1>
            {/* ThemeToggleButton removed from here */}
          </div>
          <p className="text-xs text-gray-400 mt-1">Asisten Digital Olah Skripsi</p>
        </div>
        <nav className="space-y-2">
          {FEATURES_MENU.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveFeature(item.id)}
              className={`w-full flex items-center px-4 py-3 rounded-lg transition-all duration-200 ease-in-out transform hover:scale-105 group
                ${activeFeature === item.id 
                  ? 'bg-indigo-600 text-white shadow-md ring-2 ring-indigo-400' 
                  : 'hover:bg-gray-700 hover:text-white focus:bg-gray-700 focus:text-white'
                }`}
            >
              {React.cloneElement(item.icon, { 
                className: `h-5 w-5 mr-3 ${activeFeature === item.id ? 'text-white' : 'text-gray-400 group-hover:text-white'}` 
              })}
              <span className="text-sm font-medium">{item.name}</span>
            </button>
          ))}
        </nav>
        <div className="mt-auto pt-6 text-center text-xs text-gray-500">
          <p>&copy; {new Date().getFullYear()} {APP_TITLE}</p>
          <p className="mb-1">Didukung oleh Adios (AI)</p>
          <div className="flex items-center justify-center text-gray-400">
            <ClockIcon className="w-3 h-3 mr-1" />
            <span>Sesi Aktif: {sessionDuration}</span>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Navbar;