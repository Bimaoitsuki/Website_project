
import React, { useState, useCallback } from 'react';
import { paraphraseText } from '../services/geminiService.ts';
import SectionCard from './SectionCard.tsx';
import LoadingSpinner from './LoadingSpinner.tsx';
import { ClipboardIcon, CheckIcon, ChatBubbleLeftEllipsisIcon } from '../constants.tsx';
import { GeminiResponse } from '../types.ts';

const PARAPHRASE_STYLES = [
  "Netral Akademik",
  "Lebih Formal",
  "Lebih Sederhana",
  "Untuk Audiens Umum",
  "Lebih Ringkas",
  "Lebih Deskriptif",
];

const ParaphrasingTool: React.FC = () => {
  const [inputText, setInputText] = useState<string>('');
  const [paraphraseStyle, setParaphraseStyle] = useState<string>(PARAPHRASE_STYLES[0]);
  const [paraphrasedText, setParaphrasedText] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = React.useState(false);

  const handleParaphrase = useCallback(async () => {
    if (!inputText.trim()) {
      setError("Masukkan teks yang ingin diparafrase.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setParaphrasedText('');
    try {
      const response: GeminiResponse = await paraphraseText(inputText, paraphraseStyle);
      if (response.text.startsWith("Error:")) {
        setError(response.text);
      } else {
        setParaphrasedText(response.text);
      }
    } catch (e: any) {
      setError(e.message || "Gagal memparafrase teks dengan Adios.");
    } finally {
      setIsLoading(false);
    }
  }, [inputText, paraphraseStyle]);

  const handleCopy = () => {
    if (paraphrasedText) {
      navigator.clipboard.writeText(paraphrasedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };


  return (
    <SectionCard
      title="Alat Parafrase Cerdas (Adios Turnitin Shield)"
      description="Masukkan paragraf, pilih gaya parafrase, dan Adios akan membantu menulis ulangnya untuk mengurangi potensi plagiarisme sambil mempertahankan makna inti."
    >
      <div className="space-y-4">
        <div>
          <label htmlFor="inputText" className="block text-sm font-medium text-gray-700 mb-1">
            Teks Asli:
          </label>
          <textarea
            id="inputText"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            rows={6}
            className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
            placeholder="Tempelkan teks Anda di sini..."
            disabled={isLoading}
          />
        </div>
        <div>
          <label htmlFor="paraphraseStyle" className="block text-sm font-medium text-gray-700 mb-1">
            Pilih Gaya Parafrase:
          </label>
          <select
            id="paraphraseStyle"
            value={paraphraseStyle}
            onChange={(e) => setParaphraseStyle(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
            disabled={isLoading}
          >
            {PARAPHRASE_STYLES.map((style) => (
              <option key={style} value={style}>{style}</option>
            ))}
          </select>
        </div>
        <button
          onClick={handleParaphrase}
          disabled={isLoading || !inputText.trim()}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-4 rounded-lg shadow-md disabled:opacity-50 flex items-center justify-center transition-colors"
        >
          {isLoading ? <LoadingSpinner /> : (
            <>
              <ChatBubbleLeftEllipsisIcon className="w-5 h-5 mr-2" />
              Parafrasekan Teks dengan Gaya Terpilih
            </>
          )}
        </button>
        {error && <p role="alert" aria-live="assertive" className="text-sm text-red-600 bg-red-100 p-3 rounded-lg border border-red-200">{error}</p>}
        {paraphrasedText && (
          <div className="mt-6">
            <h4 className="text-md font-semibold text-gray-700 mb-2">Hasil Parafrase dari Adios (Gaya: {paraphraseStyle}):</h4>
            <div className="relative">
                <button
                    onClick={handleCopy}
                    className="absolute top-2 right-2 bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-md text-xs flex items-center transition-colors"
                    title="Salin ke Clipboard"
                    aria-label="Salin hasil parafrase"
                >
                    {copied ? <CheckIcon className="w-4 h-4 mr-1 text-green-500" /> : <ClipboardIcon className="w-4 h-4 mr-1" />}
                    {copied ? 'Tersalin!' : 'Salin'}
                </button>
                <pre className="text-sm leading-relaxed whitespace-pre-wrap p-4 rounded-lg max-h-[400px] overflow-y-auto">
                    {paraphrasedText}
                </pre>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              <strong>Penting dari Adios:</strong> Selalu periksa kembali hasil parafrase. Pastikan maknanya sesuai dengan teks asli dan konteks akademik Anda. Gunakan alat ini sebagai bantuan, bukan pengganti pemahaman dan penulisan kritis Anda.
            </p>
          </div>
        )}
      </div>
    </SectionCard>
  );
};

export default ParaphrasingTool;