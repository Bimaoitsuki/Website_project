
import React, { useState, useCallback } from 'react';
import { getPresentationOutline } from '../services/geminiService.ts';
import SectionCard from './SectionCard.tsx';
import LoadingSpinner from './LoadingSpinner.tsx';
import { ClipboardIcon, CheckIcon, PresentationChartBarIcon } from '../constants.tsx';
import { GeminiResponse, PresentationOutlineResponse, ParsedJsonResponse, PresentationSlide } from '../types.ts';

// Utility function to parse JSON and handle markdown fences
const parseJsonFromAiResponse = <T,>(responseText: string): ParsedJsonResponse<T> => {
  let jsonStr = responseText.trim();
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
  const match = jsonStr.match(fenceRegex);
  if (match && match[2]) {
    jsonStr = match[2].trim();
  }
  try {
    return JSON.parse(jsonStr) as T;
  } catch (e) {
    console.error("Failed to parse JSON response:", e, "Raw text:", responseText);
    return { error: `Gagal mem-parse JSON dari Adios: ${e instanceof Error ? e.message : String(e)}`, rawText: responseText };
  }
};

const AUDIENCE_TYPES = ["Penguji Akademik Standar", "Penguji Teknis/Detail", "Panel Akademik Umum", "Mahasiswa/Sejawat"];
const DURATION_OPTIONS = ["Singkat (~10-15 menit)", "Standar (~20-25 menit)", "Panjang (~30-40 menit)"];

const PresentationOutline = (): JSX.Element => {
  const [thesisTopic, setThesisTopic] = useState<string>('');
  const [audience, setAudience] = useState<string>(AUDIENCE_TYPES[0]);
  const [duration, setDuration] = useState<string>(DURATION_OPTIONS[1]);
  const [outline, setOutline] = useState<string>(''); // Stores formatted string or raw text on error
  const [parsedOutline, setParsedOutline] = useState<PresentationOutlineResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [rawResponseOnError, setRawResponseOnError] = useState<string>('');
  const [copied, setCopied] = React.useState(false);

  const formatOutlineForDisplay = (parsedData: PresentationOutlineResponse): string => {
    let displayText = `Outline Presentasi untuk Topik: ${thesisTopic}\n`;
    displayText += `Audiens: ${audience}, Durasi: ${duration}\n\n`;

    parsedData.slides.forEach((slide) => {
      displayText += `Slide ${slide.slide_number || ''}: ${slide.title}\n`;
      if (slide.estimated_time) displayText += `  Estimasi Waktu: ${slide.estimated_time}\n`;
      displayText += `  Poin Utama:\n`;
      slide.main_points.forEach(point => {
        displayText += `    - ${point}\n`;
      });
      if (slide.suggested_visual) displayText += `  Saran Visual: ${slide.suggested_visual}\n`;
      displayText += "\n";
    });

    if (parsedData.general_tips && parsedData.general_tips.length > 0) {
      displayText += "Tips Umum Persiapan:\n";
      parsedData.general_tips.forEach(tip => {
        displayText += `  - ${tip}\n`;
      });
    }
    return displayText;
  };

  const handleGenerateOutline = useCallback(async () => {
    if (!thesisTopic.trim()) {
      setError("Masukkan topik skripsi Anda terlebih dahulu.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setOutline('');
    setParsedOutline(null);
    setRawResponseOnError('');

    try {
      const response: GeminiResponse = await getPresentationOutline(thesisTopic, audience, duration);
       if (response.text.startsWith("Error:")) {
        setError(response.text);
      } else {
        const parsedResult = parseJsonFromAiResponse<PresentationOutlineResponse>(response.text);
        if ('error' in parsedResult) {
          setError(`${parsedResult.error}. Menampilkan respons mentah dari Adios.`);
          setRawResponseOnError(parsedResult.rawText);
          setOutline(parsedResult.rawText); // Show raw text on parse error
        } else {
          setParsedOutline(parsedResult);
          setOutline(formatOutlineForDisplay(parsedResult));
        }
      }
    } catch (err: unknown) {
      let message = "Gagal membuat outline presentasi dari Adios.";
      if (err instanceof Error) {
        message = err.message;
      } else if (typeof err === 'string') {
        message = err;
      }
      setError(message);
    } finally {
      setIsLoading(false);
    }
  }, [thesisTopic, audience, duration]); 

  const handleCopy = () => {
    if (outline) {
      navigator.clipboard.writeText(outline);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };
  
  const renderOutlineContent = () => {
    if (parsedOutline && !rawResponseOnError) {
        return (
            <div>
                {parsedOutline.slides.map((slide, index) => (
                    <div key={index} className="mb-4 p-3 border border-gray-200 rounded-md bg-gray-50">
                        <h5 className="text-sm font-semibold text-indigo-700">
                            {(slide.slide_number ? `Slide ${slide.slide_number}: ` : '') + slide.title}
                            {slide.estimated_time && <span className="text-xs font-normal text-gray-500"> ({slide.estimated_time})</span>}
                        </h5>
                        <ul className="list-disc list-inside pl-4 text-xs mt-1">
                            {slide.main_points.map((point, pIndex) => <li key={pIndex}>{point}</li>)}
                        </ul>
                        {slide.suggested_visual && <p className="text-xs mt-1"><strong>Saran Visual:</strong> {slide.suggested_visual}</p>}
                    </div>
                ))}
                {parsedOutline.general_tips && parsedOutline.general_tips.length > 0 && (
                    <div className="mt-4 p-3 border border-green-200 rounded-md bg-green-50">
                        <h5 className="text-sm font-semibold text-green-700">Tips Umum Persiapan:</h5>
                        <ul className="list-disc list-inside pl-4 text-xs mt-1">
                            {parsedOutline.general_tips.map((tip, tIndex) => <li key={tIndex}>{tip}</li>)}
                        </ul>
                    </div>
                )}
            </div>
        );
    }
    // If there's a raw response due to parsing error, or if outline is just text
    return <pre className="text-sm leading-relaxed whitespace-pre-wrap p-4 rounded-lg max-h-[600px] overflow-y-auto">{outline}</pre>;
  };


  return (
    <SectionCard
      title="Generator Outline Presentasi Sidang Cerdas (Adios)"
      description="Masukkan topik skripsi, target audiens, dan durasi. Adios akan membantu membuat kerangka slide presentasi (dalam format JSON) yang disesuaikan."
    >
      <div className="space-y-4">
        <div>
          <label htmlFor="thesisTopicOutline" className="block text-sm font-medium text-gray-700 mb-1">
            Topik Skripsi Anda (Wajib):
          </label>
          <textarea
            id="thesisTopicOutline"
            value={thesisTopic}
            onChange={(e) => setThesisTopic(e.target.value)}
            rows={3}
            className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
            placeholder="Contoh: Pengembangan Sistem Informasi Akademik Berbasis Web dengan Fitur Notifikasi Real-time untuk Meningkatkan Efisiensi Komunikasi Kampus"
            disabled={isLoading}
            aria-label="Topik Skripsi Anda"
          />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label htmlFor="audience" className="block text-sm font-medium text-gray-700 mb-1">
                    Target Audiens (Opsional):
                </label>
                <select
                    id="audience"
                    value={audience}
                    onChange={(e) => setAudience(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
                    disabled={isLoading}
                    aria-label="Target Audiens"
                >
                    {AUDIENCE_TYPES.map(type => <option key={type} value={type}>{type}</option>)}
                </select>
            </div>
            <div>
                <label htmlFor="duration" className="block text-sm font-medium text-gray-700 mb-1">
                    Perkiraan Durasi (Opsional):
                </label>
                <select
                    id="duration"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
                    disabled={isLoading}
                    aria-label="Perkiraan Durasi Presentasi"
                >
                    {DURATION_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
            </div>
        </div>
        <button
          onClick={handleGenerateOutline}
          disabled={isLoading || !thesisTopic.trim()}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-4 rounded-lg shadow-md disabled:opacity-50 flex items-center justify-center transition-colors"
          aria-busy={isLoading}
        >
          {isLoading ? <LoadingSpinner /> : (
            <>
              <PresentationChartBarIcon className="w-5 h-5 mr-2" />
              Buat Outline Presentasi dari Adios
            </>
          )}
        </button>
        {error && !rawResponseOnError && <div role="alert" aria-live="assertive" className="text-sm text-red-600 bg-red-100 p-3 rounded-lg border border-red-200">{error}</div>}
        {error && rawResponseOnError && (
             <div role="alert" aria-live="assertive" className="text-sm text-orange-700 bg-orange-100 p-3 rounded-lg border border-orange-200">
                {error}
             </div>
        )}

        {outline && (
          <div className="mt-6">
             <div className="flex justify-between items-center mb-2">
                <h4 className="text-md font-semibold text-gray-700">
                     {rawResponseOnError ? "Respons Mentah dari Adios (Gagal Parse JSON):" : "Outline Presentasi dari Adios:"}
                </h4>
                <button
                    onClick={handleCopy}
                    className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-md text-xs flex items-center transition-colors"
                    title="Salin Outline ke Clipboard"
                    aria-label="Salin Outline ke Clipboard"
                >
                    {copied ? <CheckIcon className="w-4 h-4 mr-1 text-green-500" /> : <ClipboardIcon className="w-4 h-4 mr-1" />}
                    {copied ? 'Tersalin!' : 'Salin'}
                </button>
            </div>
            <p className="text-xs text-gray-500 mb-1">Topik: <span className="font-medium text-gray-700">{thesisTopic}</span></p>
            <p className="text-xs text-gray-500 mb-1">Audiens: <span className="font-medium text-gray-700">{audience}</span></p>
            <p className="text-xs text-gray-500 mb-2">Durasi: <span className="font-medium text-gray-700">{duration}</span></p>
            
            <div className="bg-white p-px rounded-lg border border-gray-200 shadow-sm max-h-[600px] overflow-y-auto">
                {renderOutlineContent()}
            </div>
            <p className="text-xs text-gray-500 mt-2">
              <strong>Tips Adios:</strong> Gunakan outline ini sebagai dasar yang kuat. Tambahkan detail spesifik, visual yang menarik, dan sesuaikan dengan gaya presentasi Anda. Latihan berulang kali adalah kunci keberhasilan sidang!
            </p>
          </div>
        )}
      </div>
    </SectionCard>
  );
};

export default PresentationOutline;
