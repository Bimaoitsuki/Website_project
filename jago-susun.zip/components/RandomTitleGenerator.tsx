import React, { useState, useCallback } from 'react';
import { GenerateContentResponse } from "@google/genai"; 
import { formulateThesisTitleFromQuery, generateThesisDraftFromTitle } from '../services/geminiService.ts';
import SectionCard from './SectionCard.tsx';
import LoadingSpinner from './LoadingSpinner.tsx';
import { ClipboardIcon, CheckIcon, DocumentTextIcon, LightBulbIcon } from '../constants.tsx';
import { GeminiResponse } from '../types.ts';

const ThesisDraftGenerator: React.FC = () => {
  const [researchQuery, setResearchQuery] = useState<string>(''); 
  const [finalTitle, setFinalTitle] = useState<string>('');
  const [thesisManuscript, setThesisManuscript] = useState<string>('');
  
  const [isLoadingTitle, setIsLoadingTitle] = useState<boolean>(false);
  const [isLoadingManuscript, setIsLoadingManuscript] = useState<boolean>(false);
  
  const [error, setError] = useState<string | null>(null);
  
  const [copiedTitle, setCopiedTitle] = useState(false);
  const [copiedManuscript, setCopiedManuscript] = useState(false);

  const handleFormulateTitle = useCallback(async () => {
    if (!researchQuery.trim()) {
      setError("Masukkan ide/query penelitian Anda terlebih dahulu.");
      return;
    }
    setIsLoadingTitle(true);
    setError(null);
    setFinalTitle('');
    setThesisManuscript(''); 
    try {
      const response: GeminiResponse = await formulateThesisTitleFromQuery(researchQuery);
      if (response.text.startsWith("Error:")) {
        setError(response.text);
      } else {
        setFinalTitle(response.text.trim());
      }
    } catch (e: any) {
      setError(e.message || "Gagal memformulasikan judul skripsi dengan Adios.");
    } finally {
      setIsLoadingTitle(false);
    }
  }, [researchQuery]);

  const handleGenerateManuscript = useCallback(async () => {
    if (!finalTitle) {
      setError("Silakan formulasikan judul skripsi terlebih dahulu.");
      return;
    }
    setIsLoadingManuscript(true);
    setError(null);
    setThesisManuscript(''); // Clear previous manuscript
    
    try {
      const stream: AsyncIterable<GenerateContentResponse> = await generateThesisDraftFromTitle(finalTitle);
      let accumulatedText = "";
      for await (const chunk of stream) {
        const chunkText = chunk.text; // chunk.text is correct for GenerateContentResponse
        // Check for error message within the stream chunk
        if (chunkText && typeof chunkText === 'string' && chunkText.startsWith("Error:")) { 
            setError(chunkText);
            accumulatedText = ""; // Clear any accumulated text if an error occurs mid-stream
            setThesisManuscript(''); // Also clear the displayed manuscript
            break; // Stop processing further chunks
        }
        accumulatedText += chunkText;
        setThesisManuscript(prev => prev + chunkText); // Append chunk to state
      }
      
      // If the loop completed and an error was set, thesisManuscript might have partial content before error.
      // If setError was called in the loop, this check might be redundant or ensure final state.
      if (error) { // If an error was set during streaming
        // thesisManuscript might be cleared or contain partial data depending on when error occurred.
        // setError already called, so no need to call it again unless refining the message.
      } else if (accumulatedText.startsWith("Error:") && thesisManuscript === accumulatedText) {
          // This handles cases where the entire stream output is an error message not caught above
          setError(accumulatedText);
          setThesisManuscript(''); 
      }


    } catch (e: any) {
      console.error("Streaming error in component RandomTitleGenerator:", e);
      let errorMessage = "Gagal menghasilkan naskah skripsi dengan Adios (streaming).";
      if (e instanceof Error) {
        if (e.message.includes("API Key tidak valid") || e.message.includes("API Key tidak dikonfigurasi")) {
          errorMessage = e.message;
        } else {
          errorMessage = e.message;
        }
      }
      setError(errorMessage);
      setThesisManuscript(''); // Clear manuscript on any catch-block error
    } finally {
      setIsLoadingManuscript(false);
    }
  }, [finalTitle]); // Removed 'error' from dependency array, setError updates state and triggers re-render

  const copyToClipboard = (text: string, setCopiedState: React.Dispatch<React.SetStateAction<boolean>>) => {
    if (text) {
      navigator.clipboard.writeText(text);
      setCopiedState(true);
      setTimeout(() => setCopiedState(false), 2000);
    }
  };

  return (
    <SectionCard
      title="Generator Naskah Skripsi Final (Adios)"
      description="Alur 3 tahap: 1. Anda masukkan ide/query penelitian. 2. Adios memformulasikan judul skripsi cerdas dari query Anda. 3. Adios membuat naskah skripsi final lengkap (Daftar Isi + 5 Bab) dari judul tersebut dengan target ~115rb karakter / ~12rb kata. Naskah akan muncul secara bertahap (streaming)."
    >
      <div className="space-y-6">
        {/* Tahap 1: User Input Query */}
        <div className="p-4 border border-sky-300 rounded-lg bg-sky-50">
          <h4 className="text-md font-semibold text-sky-700 mb-2">Tahap 1: Masukkan Ide/Query Penelitian Anda</h4>
          <textarea
            value={researchQuery}
            onChange={(e) => {
              setResearchQuery(e.target.value);
              setError(null); 
              setFinalTitle(''); 
              setThesisManuscript('');
            }}
            rows={4}
            className="w-full p-2.5 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 placeholder-gray-400 text-base bg-white text-gray-900"
            placeholder="Contoh: Analisis dampak penggunaan media sosial terhadap kesehatan mental remaja di perkotaan..."
            disabled={isLoadingTitle || isLoadingManuscript}
            aria-label="Ide atau Query Penelitian"
          />
           <p className="text-xs text-gray-500 mt-1">
            Semakin detail query Anda, semakin baik Adios dapat membantu memformulasikan judul.
          </p>
        </div>
        
        {error && !isLoadingManuscript && <p role="alert" aria-live="assertive" className="text-sm text-red-600 bg-red-100 p-3 rounded-lg border border-red-200 my-4">{error}</p>}
        
        <div className="p-4 border border-indigo-300 rounded-lg bg-indigo-50">
            <h4 className="text-md font-semibold text-indigo-700 mb-2">Tahap 2: Formulasikan Judul Skripsi Cerdas dari Query Anda</h4>
            <button
            onClick={handleFormulateTitle}
            disabled={isLoadingTitle || isLoadingManuscript || !researchQuery.trim()}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-5 rounded-lg shadow-md disabled:opacity-60 flex items-center justify-center transition-all duration-150 ease-in-out text-base hover:shadow-lg active:scale-95"
            aria-busy={isLoadingTitle}
            >
            {isLoadingTitle ? <LoadingSpinner /> : (
                <>
                <LightBulbIcon className="w-5 h-5 mr-2" />
                Formulasikan Judul Skripsi
                </>
            )}
            </button>
        </div>

        {finalTitle && (
           <div className="mt-6 p-4 border border-green-300 rounded-lg bg-green-50">
            <h4 className="text-lg font-semibold text-gray-700 mb-3">Judul Skripsi yang Difromulasikan Adios:</h4>
            <div className="relative bg-white p-4 rounded-lg border border-gray-200 shadow">
              <button
                onClick={() => copyToClipboard(finalTitle, setCopiedTitle)}
                className="absolute top-3 right-3 bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-md text-xs flex items-center transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500"
                title="Salin Judul ke Clipboard"
                aria-label="Salin judul skripsi yang diformulasikan"
                disabled={isLoadingManuscript}
              >
                {copiedTitle ? <CheckIcon className="w-4 h-4 mr-1 text-green-500" /> : <ClipboardIcon className="w-4 h-4 mr-1" />}
                {copiedTitle ? 'Judul Tersalin!' : 'Salin Judul'}
              </button>
              <p className="text-md md:text-lg text-gray-800 leading-relaxed whitespace-pre-wrap">
                {finalTitle}
              </p>
            </div>

            <div className="mt-6">
              <h4 className="text-md font-semibold text-green-700 mb-2">Tahap 3: Buat Naskah Skripsi Final dari Judul Ini</h4>
               {isLoadingManuscript && <p className="text-sm text-green-700 my-2">Adios sedang menulis naskah Anda secara bertahap, mohon tunggu...</p>}
              <button
                onClick={handleGenerateManuscript}
                disabled={isLoadingTitle || isLoadingManuscript || !finalTitle}
                className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-2.5 px-5 rounded-lg shadow-md disabled:opacity-60 flex items-center justify-center transition-all duration-150 ease-in-out text-base hover:shadow-lg active:scale-95"
                aria-busy={isLoadingManuscript}
              >
                {isLoadingManuscript ? <LoadingSpinner /> : (
                  <>
                    <DocumentTextIcon className="w-5 h-5 mr-2" />
                    Buat Naskah Skripsi Final (Adios)
                  </>
                )}
              </button>
            </div>
          </div>
        )}
        
        {error && isLoadingManuscript && <p role="alert" aria-live="assertive" className="text-sm text-red-600 bg-red-100 p-3 rounded-lg border border-red-200 my-4">{error}</p>}

        {(thesisManuscript && (!error || isLoadingManuscript)) && ( 
          <div className="mt-8">
            <h3 className="text-xl font-bold text-gray-700 mb-4">Naskah Skripsi Final dari Adios:</h3>
            <p className="text-sm text-gray-600 mb-1">Judul: <strong className="text-gray-700">{finalTitle}</strong></p>
            <div className="relative bg-white p-2 rounded-lg border border-gray-300 shadow-inner">
              <button
                onClick={() => copyToClipboard(thesisManuscript, setCopiedManuscript)}
                className="absolute top-3 right-3 bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-md text-xs flex items-center transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 z-10"
                title="Salin Naskah Skripsi ke Clipboard"
                aria-label="Salin naskah skripsi final"
              >
                {copiedManuscript ? <CheckIcon className="w-4 h-4 mr-1 text-green-500" /> : <ClipboardIcon className="w-4 h-4 mr-1" />}
                {copiedManuscript ? 'Naskah Tersalin!' : 'Salin Naskah'}
              </button>
              <pre className="text-sm leading-relaxed whitespace-pre-wrap p-4 rounded-lg max-h-[80vh] overflow-y-auto mt-2 bg-white text-gray-900">
                {thesisManuscript}
              </pre>
            </div>
            <p className="text-xs text-gray-500 mt-3">
              <strong>Catatan Penting dari Adios:</strong> Naskah ini dihasilkan sebagai titik awal. Anda WAJIB mereview, memverifikasi, mengedit, dan mengembangkannya lebih lanjut sesuai dengan standar akademik, panduan universitas, dan temuan penelitian Anda sendiri. Jangan mengandalkan naskah ini sepenuhnya tanpa proses kritis dan validasi independen. Pastikan juga total panjang karakter/kata sesuai ekspektasi atau kebutuhan Anda.
            </p>
          </div>
        )}
      </div>
    </SectionCard>
  );
};

export default ThesisDraftGenerator;
