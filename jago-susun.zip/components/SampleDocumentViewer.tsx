
import React, { useState, useCallback } from 'react';
import SectionCard from './SectionCard.tsx';
import { ClipboardIcon, CheckIcon, BookOpenIcon } from '../constants.tsx';
import LoadingSpinner from './LoadingSpinner.tsx';
import { generateSampleDocumentSection } from '../services/geminiService.ts';
import { GeminiResponse } from '../types.ts';

const SECTION_TYPES = [
  "Latar Belakang Masalah (Bab I)",
  "Rumusan Masalah (Bab I)",
  "Tujuan Penelitian (Bab I)",
  "Manfaat Penelitian (Bab I)",
  "Sistematika Penulisan (Bab I)",
  "Landasan Teori (Bab II)",
  "Penelitian Terdahulu (Bab II)",
  "Kerangka Pemikiran/Hipotesis (Bab II)",
  "Jenis Penelitian (Bab III)",
  "Populasi dan Sampel (Bab III)",
  "Teknik Pengumpulan Data (Bab III)",
  "Teknik Analisis Data (Bab III)",
  "Deskripsi Data/Temuan Kualitatif (Bab IV - Contoh)",
  "Deskripsi Data/Temuan Kuantitatif (Bab IV - Contoh)",
  "Pembahasan Hasil (Bab IV - Contoh)",
  "Kesimpulan (Bab V)",
  "Saran (Bab V)",
];

const SampleDocumentViewer: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [sectionType, setSectionType] = useState(SECTION_TYPES[0]);
  const [sampleContent, setSampleContent] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleGenerateSample = useCallback(async () => {
    if (!topic.trim() || !sectionType.trim()) {
      setError("Masukkan topik skripsi dan pilih jenis bagian terlebih dahulu.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setSampleContent('');
    try {
      const response: GeminiResponse = await generateSampleDocumentSection(topic, sectionType);
      if (response.text.startsWith("Error:")) {
        setError(response.text);
      } else {
        setSampleContent(response.text);
      }
    } catch (e: any) {
      setError(e.message || "Gagal menghasilkan contoh bagian dokumen dari Adios.");
    } finally {
      setIsLoading(false);
    }
  }, [topic, sectionType]);

  const handleCopy = () => {
    if (sampleContent) {
      navigator.clipboard.writeText(sampleContent);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <SectionCard
      title="Generator Contoh Bagian Dokumen Skripsi (Adios)"
      description="Masukkan topik skripsi Anda dan pilih jenis bagian yang ingin dibuatkan contohnya. Adios akan membuatkan contoh konten yang relevan dan terstruktur, lengkap dengan placeholder untuk Anda isi."
    >
      <div className="space-y-4">
        <div>
          <label htmlFor="thesisTopic" className="block text-sm font-medium text-gray-700 mb-1">
            Topik Skripsi Anda:
          </label>
          <textarea
            id="thesisTopic"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            rows={3}
            className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
            placeholder="Contoh: Analisis Pengaruh Media Sosial terhadap Prestasi Akademik Mahasiswa di Era Digital"
            disabled={isLoading}
          />
        </div>
        <div>
          <label htmlFor="sectionType" className="block text-sm font-medium text-gray-700 mb-1">
            Pilih Jenis Bagian Dokumen:
          </label>
          <select
            id="sectionType"
            value={sectionType}
            onChange={(e) => setSectionType(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
            disabled={isLoading}
          >
            {SECTION_TYPES.map((type) => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>
        <button
          onClick={handleGenerateSample}
          disabled={isLoading || !topic.trim() || !sectionType.trim()}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-4 rounded-lg shadow-md disabled:opacity-50 flex items-center justify-center transition-colors"
        >
          {isLoading ? <LoadingSpinner /> : (
            <>
              <BookOpenIcon className="w-5 h-5 mr-2" />
              Buat Contoh Bagian Dokumen dari Adios
            </>
          )}
        </button>

        {error && <p role="alert" aria-live="assertive" className="text-sm text-red-600 bg-red-100 p-3 rounded-lg border border-red-200">{error}</p>}
        
        {sampleContent && (
          <div className="mt-6">
            <h4 className="text-md font-semibold text-gray-700 mb-2">Contoh Bagian Dokumen dari Adios:</h4>
            <p className="text-xs text-gray-500 mb-1">Topik: <span className="font-medium text-gray-700">{topic}</span></p>
            <p className="text-xs text-gray-500 mb-2">Bagian: <span className="font-medium text-gray-700">{sectionType}</span></p>
            <div className="relative">
              <button
                onClick={handleCopy}
                className="absolute top-2 right-2 bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-md text-xs flex items-center transition-colors"
                title="Salin Contoh ke Clipboard"
                aria-label="Salin contoh bagian dokumen"
              >
                {copied ? <CheckIcon className="w-4 h-4 mr-1 text-green-500" /> : <ClipboardIcon className="w-4 h-4 mr-1" />}
                {copied ? 'Tersalin!' : 'Salin'}
              </button>
              <pre className="text-sm leading-relaxed whitespace-pre-wrap p-4 rounded-lg max-h-[600px] overflow-y-auto">
                {sampleContent.trim()}
              </pre>
            </div>
            <p className="text-xs text-gray-500 mt-3">
              <strong>Catatan Adios:</strong> Contoh ini dihasilkan sebagai panduan. Anda WAJIB memvalidasi, menyesuaikan, dan mengisi placeholder dengan data, analisis, serta referensi spesifik penelitian Anda.
            </p>
          </div>
        )}
      </div>
    </SectionCard>
  );
};

export default SampleDocumentViewer;