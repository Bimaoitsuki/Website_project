
import React from 'react';

interface SectionCardProps {
  title: string;
  description?: string;
  children: React.ReactNode;
}

const SectionCard: React.FC<SectionCardProps> = ({ title, description, children }) => {
  return (
    <div className="bg-white shadow-lg rounded-xl p-6 mb-8 border border-gray-200">
      <h3 className="text-xl font-semibold text-gray-800 mb-2">{title}</h3>
      {description && <p className="text-sm text-gray-600 mb-4">{description}</p>}
      <div className="space-y-4">
        {children}
      </div>
    </div>
  );
};

export default SectionCard;