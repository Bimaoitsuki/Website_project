
import React, { useState, useEffect, useCallback } from 'react';
import { ChecklistCategory, ChecklistItem, GeminiResponse, CustomChecklistResponse, AiChecklistCategory, AiChecklistItem, ParsedJsonResponse } from '../types.ts';
import SectionCard from './SectionCard.tsx';
import LoadingSpinner from './LoadingSpinner.tsx';
import { getCustomChecklist } from '../services/geminiService.ts';
import { ClipboardIcon, CheckIcon, ClipboardDocumentCheckIcon } from '../constants.tsx';

// Utility function to parse JSON and handle markdown fences
const parseJsonFromAiResponse = <T,>(responseText: string): ParsedJsonResponse<T> => {
  let jsonStr = responseText.trim();
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
  const match = jsonStr.match(fenceRegex);
  if (match && match[2]) {
    jsonStr = match[2].trim();
  }
  try {
    return JSON.parse(jsonStr) as T;
  } catch (e) {
    console.error("Failed to parse JSON response:", e, "Raw text:", responseText);
    return { error: `Gagal mem-parse JSON dari Adios: ${e instanceof Error ? e.message : String(e)}`, rawText: responseText };
  }
};

const initialChecklistData: ChecklistCategory[] = [
  {
    title: 'Format Fisik Dokumen (Contoh Default)',
    items: [
      { id: 'f1', text: 'Cover skripsi sesuai standar (misal: biru tua untuk S1, merah untuk S2/S3)', checked: false, details: "Pastikan warna dan layout cover sesuai pedoman fakultas." },
      { id: 'f2', text: 'Margin halaman konsisten (misal: 4-3-3-3 cm)', checked: false, details: "Top: 4cm, Right: 3cm, Bottom: 3cm, Left: 3cm. Periksa semua halaman." },
    ],
  },
  {
    title: 'Konten Skripsi (Contoh Default)',
    items: [
      { id: 'c1', text: 'Judul skripsi final dan disetujui', checked: false },
      { id: 'c2', text: 'Abstrak (Bahasa Indonesia & Inggris) jelas dan ringkas', checked: false, details: "Maksimum 250 kata, mencakup tujuan, metode, hasil, kesimpulan." },
    ],
  },
];


const SubmissionChecklist: React.FC = () => {
  const [checklist, setChecklist] = useState<ChecklistCategory[]>(initialChecklistData);
  const [major, setMajor] = useState<string>('');
  const [specificConcerns, setSpecificConcerns] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [rawResponseOnError, setRawResponseOnError] = useState<string>('');
  const [copied, setCopied] = React.useState(false);

  const handleToggle = (categoryIndex: number, itemIndex: number) => {
    const newChecklist = checklist.map((category, cIdx) => {
        if (cIdx === categoryIndex) {
            return {
                ...category,
                items: category.items.map((item, iIdx) => {
                    if (iIdx === itemIndex) {
                        return { ...item, checked: !item.checked };
                    }
                    return item;
                })
            };
        }
        return category;
    });
    setChecklist(newChecklist);
  };
  
  const transformAiChecklistToAppFormat = (aiCategories: AiChecklistCategory[]): ChecklistCategory[] => {
    return aiCategories.map((aiCategory, catIndex) => ({
      title: aiCategory.title,
      items: aiCategory.items.map((aiItem, itemIndex) => ({
        id: `custom-${catIndex}-${itemIndex}-${Date.now()}`, // ensure unique ID
        text: aiItem.text,
        checked: false,
        details: aiItem.details,
      })),
    }));
  };


  const handleGenerateCustomChecklist = useCallback(async () => {
    if (!major.trim()) {
      setError("Masukkan jurusan Anda untuk checklist kustom.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setRawResponseOnError('');
    try {
      const response = await getCustomChecklist(major, specificConcerns);
      if (response.text.startsWith("Error:")) {
        setError(response.text);
        setChecklist(initialChecklistData); 
      } else {
        const parsedResult = parseJsonFromAiResponse<CustomChecklistResponse>(response.text);
        if ('error' in parsedResult) {
          setError(`${parsedResult.error}. Menampilkan respons mentah dari Adios.`);
          setRawResponseOnError(parsedResult.rawText);
          setChecklist(initialChecklistData); // Revert to initial on parse error or show raw?
        } else {
          if (parsedResult.categories && parsedResult.categories.length > 0) {
            setChecklist(transformAiChecklistToAppFormat(parsedResult.categories));
          } else {
            setError("Adios mengembalikan respons JSON, tetapi tidak ada kategori checklist yang valid. Coba lagi atau periksa respons mentah jika ada.");
            setChecklist(initialChecklistData);
            setRawResponseOnError(response.text); // Show raw response if categories are empty
          }
        }
      }
    } catch (e: any) {
      setError(e.message || "Gagal membuat checklist kustom dari Adios.");
      setChecklist(initialChecklistData); 
    } finally {
      setIsLoading(false);
    }
  }, [major, specificConcerns]);

  const getChecklistAsText = () => {
    if (rawResponseOnError) {
        return `Respons Mentah Adios (Gagal Parse JSON):\n${rawResponseOnError}`;
    }
    let text = "Checklist Final Submit Skripsi:\n\n";
    checklist.forEach(category => {
      text += `Kategori: ${category.title}\n`;
      category.items.forEach(item => {
        text += `[${item.checked ? 'X' : ' '}] ${item.text}${item.details ? ` (${item.details})` : ''}\n`;
      });
      text += "\n";
    });
    return text;
  };

  const handleCopy = () => {
    const textToCopy = getChecklistAsText();
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };


  return (
    <SectionCard
      title="Checklist Final Submit Skripsi"
      description="Pastikan semua item terpenuhi sebelum submit skripsi Anda. Anda juga bisa meminta Adios membuat checklist kustom (format JSON) untuk jurusan dan kekhawatiran spesifik Anda."
    >
      <div className="mb-6 p-4 border border-indigo-300 rounded-lg bg-indigo-50">
        <h4 className="text-md font-semibold text-indigo-700 mb-2">Buat Checklist Kustom dari Adios (Opsional)</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
            <label htmlFor="major" className="block text-sm font-medium text-gray-700 mb-1">Jurusan Anda:</label>
            <input
                type="text"
                id="major"
                value={major}
                onChange={(e) => setMajor(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
                placeholder="Contoh: Teknik Informatika"
                disabled={isLoading}
            />
            </div>
            <div>
            <label htmlFor="specificConcerns" className="block text-sm font-medium text-gray-700 mb-1">
                Kekhawatiran atau Fokus Khusus Saat Ini (Opsional)?
            </label>
            <input
                type="text"
                id="specificConcerns"
                value={specificConcerns}
                onChange={(e) => setSpecificConcerns(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white text-gray-900"
                placeholder="Contoh: Penulisan sitasi gaya Bluebook, Analisis data kuantitatif"
                disabled={isLoading}
            />
            </div>
        </div>
        <button
          onClick={handleGenerateCustomChecklist}
          disabled={isLoading || !major.trim()}
          className="mt-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-4 rounded-lg shadow-md disabled:opacity-50 flex items-center justify-center transition-colors"
        >
          {isLoading && major ? <LoadingSpinner /> : (
            <>
              <ClipboardDocumentCheckIcon className="w-5 h-5 mr-2" />
              Buat Checklist Kustom dari Adios
            </>
          )}
        </button>
        {isLoading && major && <p className="text-xs text-indigo-600 mt-1">Adios sedang membuat checklist untuk jurusan {major}...</p>}
      </div>

      {error && !rawResponseOnError && <p role="alert" aria-live="assertive" className="text-sm text-red-600 bg-red-100 p-3 rounded-lg border border-red-200 mb-4">{error}</p>}
      {error && rawResponseOnError && (
         <div role="alert" aria-live="assertive" className="text-sm text-orange-700 bg-orange-100 p-3 rounded-lg border border-orange-200 mb-4">
            {error}
            <h5 className="font-semibold mt-2">Respons Mentah:</h5>
            <pre className="text-xs whitespace-pre-wrap max-h-40 overflow-y-auto bg-gray-800 text-gray-200 p-2 rounded-md">{rawResponseOnError}</pre>
         </div>
      )}
      
      <div className="relative">
        <button
            onClick={handleCopy}
            className="absolute top-0 right-0 bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-md text-xs flex items-center transition-colors z-10"
            title="Salin Checklist ke Clipboard"
            aria-label="Salin Checklist"
        >
            {copied ? <CheckIcon className="w-4 h-4 mr-1 text-green-500" /> : <ClipboardIcon className="w-4 h-4 mr-1" />}
            {copied ? 'Tersalin!' : 'Salin'}
        </button>
        {checklist.map((category, categoryIndex) => (
            <div key={`${category.title.replace(/\s/g, '-')}-${categoryIndex}`} className="mb-6">
            <h4 className="text-lg font-semibold text-gray-700 mb-3 border-b pb-2 border-gray-300">{category.title}</h4>
            <ul className="space-y-2">
                {category.items.map((item, itemIndex) => (
                <li key={item.id} className="flex items-start p-2 rounded-lg hover:bg-gray-50 transition-colors">
                    <input
                    type="checkbox"
                    id={item.id}
                    checked={item.checked}
                    onChange={() => handleToggle(categoryIndex, itemIndex)}
                    className="h-5 w-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 mt-0.5 cursor-pointer bg-white"
                    />
                    <label htmlFor={item.id} className={`ml-3 text-sm ${item.checked ? 'line-through text-gray-500' : 'text-gray-700'} cursor-pointer`}>
                    {item.text}
                    {item.details && <p className="text-xs text-gray-400 mt-0.5">{item.details}</p>}
                    </label>
                </li>
                ))}
                 {category.items.length === 0 && <p className="text-xs text-gray-500 pl-2">Tidak ada item untuk kategori ini.</p>}
            </ul>
            </div>
        ))}
         {checklist.length === 0 && !isLoading && !error && <p className="text-gray-500">Tidak ada checklist untuk ditampilkan. Coba buat checklist kustom.</p>}
         {checklist.length === 0 && !isLoading && error && rawResponseOnError && <p className="text-gray-500">Gagal memuat checklist kustom. Periksa respons mentah di atas.</p>}
      </div>
    </SectionCard>
  );
};

export default SubmissionChecklist;
