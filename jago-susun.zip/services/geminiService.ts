
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GEMINI_TEXT_MODEL } from '../constants.tsx';
import { GroundingChunk, GeminiResponse, Candidate } from "../types.ts";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "MISSING_API_KEY_PLACEHOLDER" });

const generateContent = async (promptText: string, systemInstruction?: string, isJsonOutput: boolean = false, useGoogleSearch: boolean = false): Promise<GeminiResponse> => {
  if (!API_KEY || API_KEY === "MISSING_API_KEY_PLACEHOLDER") {
    return { text: "Error: API Key tidak dikonfigurasi dengan benar. Silakan set variabel lingkungan API_KEY." };
  }
  try {
    const generationConfig: any = {};
    if (systemInstruction) {
      generationConfig.systemInstruction = systemInstruction;
    } else {
      generationConfig.systemInstruction = "Anda adalah Adios, Asisten Digital Olah Skripsi yang cerdas, membantu, dan teliti.";
    }

    if (isJsonOutput) {
      generationConfig.responseMimeType = "application/json";
    }

    let toolsConfig: any[] | undefined = undefined;
    if (useGoogleSearch) {
      toolsConfig = [{googleSearch: {}}];
      if (generationConfig.responseMimeType === "application/json") {
        delete generationConfig.responseMimeType;
         console.warn("responseMimeType 'application/json' was removed because it's not compatible with Google Search tool.");
      }
    }

    const requestParameters: any = {
      model: GEMINI_TEXT_MODEL,
      contents: promptText,
    };

    if (Object.keys(generationConfig).length > 0) {
      requestParameters.config = generationConfig;
    }
    if (toolsConfig && toolsConfig.length > 0) {
      requestParameters.config = { ...(requestParameters.config || {}), tools: toolsConfig }; // Correctly merge tools into config
    }
    
    const response: GenerateContentResponse = await ai.models.generateContent(requestParameters);
    
    const result: GeminiResponse = { text: response.text };
    if (response.candidates && response.candidates[0]?.groundingMetadata?.groundingChunks) {
       result.candidates = [{ groundingMetadata: { groundingChunks: response.candidates[0].groundingMetadata.groundingChunks as GroundingChunk[] } }] as Candidate[];
    }
    return result;

  } catch (error) {
    console.error("Gemini API call failed:", error);
    if (error instanceof Error) {
        if (error.message.includes("API key not valid") || error.message.includes("API_KEY_INVALID")) {
             return { text: `Error: API Key tidak valid. Pastikan API Key Anda benar dan memiliki izin yang diperlukan.` };
        }
        return { text: `Error: ${error.message}` };
    }
    return { text: "Terjadi kesalahan saat menghubungi Adios. Silakan coba lagi." };
  }
};

export const getFormattingAdvice = async (textSnippet: string, documentContext: string): Promise<GeminiResponse> => {
  const prompt = `
Analisis cuplikan teks berikut dan berikan saran formatting akademik yang spesifik dan detail.
Konteks Dokumen: "${documentContext}"
Cuplikan Teks Pengguna:
---
${textSnippet}
---

Tugas Anda:
1.  Identifikasi elemen-elemen penting dalam cuplikan teks (misalnya, apakah ini heading, body text, kutipan, daftar, dll.?).
2.  Berikan rekomendasi formatting yang paling sesuai untuk setiap elemen yang teridentifikasi, mengacu pada standar penulisan akademik umum (misalnya, Times New Roman, ukuran font, spasi, perataan, indentasi). Jelaskan MENGAPA rekomendasi tersebut diberikan.
3.  Jika memungkinkan dan relevan, berikan contoh bagaimana cuplikan teks tersebut akan terlihat SETELAH diformat sesuai saran Anda.
4.  Sertakan catatan jika ada aturan umum formatting yang perlu diperhatikan pengguna terkait konteks dokumen yang diberikan.
5.  Output harus terstruktur, jelas, dan mudah dipahami.

Contoh Output (struktur yang diharapkan):
---
**Analisis & Rekomendasi Formatting untuk Konteks: [Konteks Dokumen Diulang]**

**1. Elemen Teridentifikasi: [Nama Elemen, misal: Paragraf Isi Utama]**
   - **Rekomendasi:**
     - Font: Times New Roman, 12pt
     - Perataan: Justify
     - Spasi: 1.5 lines
     - Indentasi Paragraf Pertama: 0.5 inci (atau sekitar 1.27 cm)
   - **Alasan:** [Jelaskan mengapa ini standar/baik]
   - **Contoh Penerapan (Jika Teks Asli Cukup Panjang):**
     [Contoh teks pengguna yang sudah diformat jika memungkinkan]

**2. Elemen Teridentifikasi: [Nama Elemen Lain, misal: Sub-Judul]**
   - **Rekomendasi:**
     - Font: Times New Roman, 12pt, Bold, Title Case
     - Perataan: Kiri
   - **Alasan:** [Jelaskan mengapa]

**Catatan Umum Tambahan:**
- [Catatan 1, misal: Pastikan konsistensi margin halaman...]
- [Catatan 2, misal: Untuk kutipan langsung lebih dari 40 kata...]
---
`;
  return generateContent(prompt, "Anda adalah Adios, seorang ahli formatting dokumen akademik yang sangat teliti. Anda membantu pengguna dengan memberikan saran formatting yang detail dan spesifik berdasarkan cuplikan teks dan konteks dokumen yang mereka berikan.");
};

export const generateSampleDocumentSection = async (topic: string, sectionType: string): Promise<GeminiResponse> => {
  const prompt = `
Buatkan contoh bagian skripsi spesifik untuk Topik: "${topic}".
Jenis Bagian yang Diminta: "${sectionType}"

Tugas Anda:
1.  Hasilkan konten contoh yang relevan untuk bagian "${sectionType}" dari sebuah skripsi dengan topik "${topic}".
2.  Konten harus ditulis dengan gaya bahasa akademik yang baik, logis, dan terstruktur.
3.  Sertakan placeholder yang jelas seperti [MASUKKAN DATA/ANALISIS SPESIFIK ANDA DI SINI] atau [SESUAIKAN DENGAN TEMUAN PENELITIAN ANDA] pada bagian-bagian di mana pengguna HARUS memasukkan informasi, data, atau analisis spesifik mereka sendiri.
4.  Berikan sedikit panduan atau konteks di sekitar placeholder tersebut untuk membantu pengguna memahami apa yang perlu mereka isi.
5.  Jika bagian tersebut adalah "Latar Belakang Masalah", pastikan mencakup elemen seperti konteks, urgensi, gap penelitian (placeholder untuk detail pengguna).
6.  Jika bagian tersebut adalah "Rumusan Masalah", berikan contoh 2-3 rumusan masalah berbentuk pertanyaan yang relevan dengan topik (pengguna akan menyesuaikannya).
7.  Jika bagian tersebut adalah "Metodologi Penelitian", sebutkan contoh pendekatan, populasi/sampel (dengan placeholder), teknik pengumpulan data (dengan placeholder), dan teknik analisis data (dengan placeholder), beserta justifikasi singkat (dengan placeholder untuk justifikasi detail pengguna).
8.  Panjang contoh bagian harus proporsional (misalnya, Latar Belakang bisa 3-4 paragraf contoh, Rumusan Masalah beberapa poin).
9.  Format output dengan jelas, gunakan sub-judul jika perlu sesuai standar penulisan bagian yang diminta.

Contoh Output untuk Bagian "Latar Belakang Masalah" (struktur yang diharapkan):
---
**Contoh Bagian: Latar Belakang Masalah**
**Untuk Topik: [Topik Diulang]**

[Paragraf pengantar yang menjelaskan konteks umum topik "${topic}".]

[Paragraf yang menyoroti masalah spesifik atau gap penelitian terkait topik "${topic}". Di sini, Anda dapat memasukkan placeholder seperti: "Fenomena [X] yang diamati di [konteks spesifik pengguna] menunjukkan adanya [masalah/isu]. Data awal dari [SUMBER DATA PENGGUNA] mengindikasikan bahwa [detail data pengguna]... Hal ini menunjukkan adanya kebutuhan mendesak untuk penelitian lebih lanjut mengenai [aspek spesifik topik "${topic}"]."]

[Paragraf yang menjelaskan signifikansi dan urgensi penelitian dengan topik "${topic}", bisa diakhiri dengan placeholder seperti: "Oleh karena itu, penelitian ini bertujuan untuk [TUJUAN UMUM PENELITIAN PENGGUNA] guna memberikan kontribusi pada [bidang keilmuan/praktis PENGGUNA]."]
---
`;
  return generateContent(prompt, "Anda adalah Adios, seorang penulis akademik berpengalaman yang bertugas membuat contoh bagian-bagian skripsi yang disesuaikan dengan topik dan jenis bagian yang diminta pengguna. Anda menyertakan placeholder dan panduan untuk membantu pengguna mengisinya dengan data mereka sendiri.");
};

export const suggestRelevantSources = async (topic: string): Promise<GeminiResponse> => {
  const prompt = `Carikan dan sarankan 3-5 sumber artikel ilmiah atau publikasi akademik yang sangat relevan (utamakan 5 tahun terakhir jika memungkinkan) untuk topik penelitian berikut: "${topic}". 
Berikan output dalam format daftar, masing-masing item berisi:
1. Judul Artikel/Publikasi
2. Penulis Utama (jika mudah ditemukan)
3. Tahun Publikasi (jika mudah ditemukan)
4. URL (jika tersedia dan merupakan sumber terbuka atau memiliki DOI yang bisa dicari)
5. Sedikit catatan mengapa sumber ini mungkin relevan (1-2 kalimat).

Contoh format output per item:
- Judul: [Judul Artikel]
  Penulis: [Nama Penulis Utama, misal: Smith, J.]
  Tahun: [Tahun]
  URL/DOI: [URL atau DOI]
  Catatan Relevansi: [Penjelasan singkat relevansi dengan topik]

Fokus pada sumber-sumber yang kredibel dan berpotensi berguna untuk tinjauan pustaka.`;
  return generateContent(prompt, "Anda adalah Adios, asisten peneliti AI yang bertugas mencari dan merekomendasikan sumber-sumber akademik relevan berdasarkan topik penelitian yang diberikan, menggunakan Google Search.", false, true);
};

export const formatReferences = async (urls: string[], style: string): Promise<GeminiResponse> => {
  const prompt = `Konversi URL berikut ke format referensi ${style}. Jika URL adalah DOI (misal, diawali https://doi.org/), dapatkan metadata yang diperlukan untuk sitasi lengkap. Berikan output hanya daftar referensi yang diformat, masing-masing di baris baru. Jika URL tidak valid atau tidak dapat diakses untuk mendapatkan detail sitasi, berikan catatan singkat di bawah URL tersebut.
Contoh input URL:
${urls.join('\n')}

Contoh Output yang Diharapkan (untuk satu URL):
Nama Belakang, I. A. (Tahun). Judul artikel. *Nama Jurnal*, *Volume*(Issue), halaman. DOI atau URL
(Atau format lain sesuai gaya ${style} yang diminta)
`;
  return generateContent(prompt, `Anda adalah Adios, asistan ahli dalam membuat daftar pustaka berbagai format (${style}). Anda berusaha sebaik mungkin untuk mengambil metadata dari URL/DOI untuk sitasi yang lengkap.`);
};

export const paraphraseText = async (text: string, paraphraseStyle?: string): Promise<GeminiResponse> => {
  let styleInstruction = "Parafrasekan teks berikut untuk membantu mengurangi potensi plagiarisme sambil mempertahankan makna aslinya.";
  if (paraphraseStyle && paraphraseStyle !== "Netral Akademik") {
    styleInstruction = `Parafrasekan teks berikut dengan gaya "${paraphraseStyle}" sambil mempertahankan makna aslinya dan menjaga integritas akademik.`;
  }
  
  const prompt = `${styleInstruction} Berikan hanya teks yang sudah diparafrase, tanpa komentar tambahan:\n\n"${text}"`;
  return generateContent(prompt, "Anda adalah Adios, asisten ahli dalam menulis ulang teks akademik secara profesional dan sesuai dengan gaya yang diminta.");
};

export const getVizRecommendation = async (dataDescription: string, researchQuestion?: string): Promise<GeminiResponse> => {
  const prompt = `
Berdasarkan deskripsi data berikut:
"${dataDescription}"

${researchQuestion ? `Dan pertanyaan utama yang ingin dijawab dengan visualisasi: "${researchQuestion}"` : ""}

Tugas Anda:
Rekomendasikan 1-2 jenis grafik yang paling sesuai. Untuk setiap grafik: jelaskan mengapa cocok, dan berikan contoh representasi tekstual sederhana atau deskripsi visualisasinya (termasuk sumbu dengan placeholder data).

Format jawaban HANYA sebagai objek JSON yang valid dengan struktur berikut:
{
  "recommendations": [
    {
      "type": "Nama Jenis Grafik (misal: Diagram Batang)",
      "reason": "Penjelasan mengapa grafik ini cocok untuk data dan pertanyaan penelitian Anda.",
      "example_representation": "Deskripsi tekstual atau contoh ASCII art sederhana dari visualisasi. Contoh: Sumbu X: [Kategori Produk], Sumbu Y: [Jumlah Penjualan]. Setiap batang mewakili satu produk.",
      "axes_placeholders": { "x_axis": "[Isi dengan kategori spesifik Anda]", "y_axis": "[Isi dengan metrik spesifik Anda]" },
      "suggested_title": "[Saran judul grafik yang relevan dengan data Anda]"
    }
    // ... rekomendasi lain jika ada
  ]
}
Pastikan output hanya berupa JSON, tanpa teks tambahan sebelum atau sesudah.
`;
  return generateContent(prompt, "Anda adalah Adios, seorang analis data ahli visualisasi. Anda memberikan rekomendasi grafik dalam format JSON.", true);
};

export const getPresentationOutline = async (thesisTopic: string, audience?: string, duration?: string): Promise<GeminiResponse> => {
  let context = `Buatkan outline slide presentasi PowerPoint untuk sidang skripsi topik: "${thesisTopic}".`;
  if (audience) context += ` Audiens: "${audience}".`;
  if (duration) context += ` Durasi: "${duration}".`;

  const prompt = `
${context}

Tugas Anda:
Buat struktur outline slide yang logis. Untuk setiap slide: judul, poin utama, saran visual, dan estimasi waktu (jika durasi diberikan). Sesuaikan dengan audiens. Sertakan tips umum di akhir.

Format output HANYA sebagai objek JSON yang valid dengan struktur berikut:
{
  "slides": [
    {
      "slide_number": "Nomor Slide (misal: 1)",
      "title": "Judul Slide yang Disarankan",
      "estimated_time": "Estimasi Waktu (misal: 2 menit, jika ada durasi)",
      "main_points": [
        "Poin Utama 1 pada slide ini",
        "Poin Utama 2 pada slide ini"
      ],
      "suggested_visual": "Saran visual (misal: Diagram Kerangka Pemikiran, Grafik Hasil X)"
    }
    // ... slide lainnya
  ],
  "general_tips": [
    "Tips umum persiapan presentasi 1",
    "Tips umum persiapan presentasi 2"
  ]
}
Pastikan output hanya berupa JSON, tanpa teks tambahan.
`;
  return generateContent(prompt, "Anda adalah Adios, konsultan akademik presentasi sidang. Anda membuat outline presentasi dalam format JSON.", true);
};

export const getCustomChecklist = async (major: string, specificConcerns?: string): Promise<GeminiResponse> => {
    const prompt = `
Buatkan checklist persiapan submit skripsi detail untuk mahasiswa jurusan "${major}".
${specificConcerns ? `Fokus khusus pada: "${specificConcerns}". Berikan perhatian ekstra pada hal ini.` : ''}

Tugas Anda:
Sertakan poin umum (Format Fisik, Konten, Administratif) dan poin SPESIFIK untuk jurusan "${major}".
Jika ada "specificConcerns", buat sub-kategori "Mengatasi Kekhawatiran: ${specificConcerns}".
Format output HANYA sebagai objek JSON yang valid dengan struktur berikut:
{
  "categories": [
    {
      "title": "Judul Kategori (misal: I. Persiapan Konten Substansial)",
      "items": [
        { "text": "Teks item checklist", "details": "Detail atau tips singkat (opsional)" }
        // ... item lainnya dalam kategori ini
      ]
    }
    // ... kategori lainnya
  ]
}
Pastikan output hanya berupa JSON, tanpa teks tambahan sebelum atau sesudahnya.
`;
    return generateContent(prompt, "Anda adalah Adios, dosen pembimbing skripsi. Anda membuat checklist submit skripsi kustom dalam format JSON.", true);
};

export const formulateThesisTitleFromQuery = async (query: string): Promise<GeminiResponse> => {
  const prompt = `Berdasarkan ide/query penelitian berikut: "${query}", formulasikan satu judul skripsi/tesis yang formal, cerdas, tepat, informatif, dan menarik. Judul harus mencerminkan lingkup penelitian yang jelas dan menggunakan bahasa akademik yang baik. Pastikan output HANYA berupa judulnya saja, tanpa penjelasan atau format tambahan.`;
  return generateContent(
    prompt,
    "Anda adalah Adios, seorang akademisi ahli dalam merumuskan judul penelitian. Tugas Anda adalah mengubah ide/query penelitian menjadi judul skripsi/tesis yang sangat baik, jelas, dan berbobot akademis."
  );
};

// --- Modified for Streaming ---
export const generateThesisDraftFromTitle = async (title: string): Promise<AsyncIterable<GenerateContentResponse>> => {
  const draftPrompt = `
Judul Skripsi Final: "${title}"

Buatkan NASKAH SKRIPSI LENGKAP dan FINAL untuk judul di atas, dengan target panjang sekitar 115.000 karakter atau setara dengan kurang lebih 12.000 kata.
Struktur naskah adalah sebagai berikut. Seluruh konten harus ditulis dalam Bahasa Indonesia yang formal, akademik, logis, cerdas, cermat, dan 'to the point' tanpa basa basi. Gunakan pemikiran analitis dan kritis.
Untuk bagian yang memerlukan data spesifik, analisis mendalam, atau justifikasi yang hanya bisa datang dari peneliti, gunakan placeholder yang jelas seperti [CONTOH_PLACEHOLDER_ANDA_DI_SINI] dan berikan sedikit panduan atau contoh bagaimana placeholder tersebut bisa diisi. Sediakan juga catatan AI seperti (Adios: Pastikan Anda memvalidasi dan memperkaya bagian ini dengan referensi aktual.) untuk mengingatkan pengguna.

--- AWAL DAFTAR ISI ---
(Adios: Buatlah Daftar Isi yang komprehensif, mencakup semua bab dan sub-bab utama yang akan Anda hasilkan di bawah ini. Nomor halaman boleh fiktif atau tidak disertakan, fokus pada struktur daftar isi yang benar.)
--- AKHIR DAFTAR ISI ---

--- AWAL BAB I: PENDAHULUAN ---
(Adios: Penanda Awal dan Akhir Bab/Sub-bab harus sangat jelas seperti ini)
A. Latar Belakang Masalah
   - Tuliskan minimal 3-4 paragraf yang kuat dan relevan dengan judul "${title}". Paragraf harus menjelaskan konteks masalah secara mendalam, menyoroti gap penelitian atau isu krusial, signifikansi masalah, dan urgensi penelitian ini dilakukan.
   - (Adios: Pastikan Anda mengaitkan ini dengan fenomena terkini atau data pendukung jika ada. Pengguna harus memvalidasi dan memperkaya bagian ini dengan referensi aktual.)
   - [MASUKKAN CONTOH FENOMENA SPESIFIK ATAU DATA AWAL YANG MENDASARI PENELITIAN ANDA TERKAIT JUDUL "${title}". CONTOH: "Berdasarkan data dari [Sumber Data Fiktif/Nyata], terlihat bahwa [Deskripsi Fenomena]..."]
   - Jika relevan dengan topik, salah satu paragraf harus berupa kutipan langsung (lebih dari 40 kata) dari sumber fiktif yang sangat kredibel atau konsep umum yang mendukung argumen. Pastikan kutipan ini logis dan diformat sebagai block quote.
B. Rumusan Masalah
   - Buatlah minimal 3-4 poin rumusan masalah dalam format pertanyaan yang spesifik, jelas, terukur, dan dapat dijawab melalui penelitian berdasarkan judul "${title}".
   - (Adios: Pengguna harus memastikan rumusan masalah ini benar-benar fokus dan relevan dengan lingkup penelitian yang akan dilakukan.)
C. Tujuan Penelitian
   - Jelaskan 2-3 tujuan penelitian yang konkret dan sinkron secara langsung dengan setiap poin rumusan masalah.
D. Manfaat Penelitian
   - Jelaskan manfaat penelitian dari dua sisi:
     1. Manfaat Teoritis/Akademis: Kontribusi penelitian terhadap pengembangan ilmu pengetahuan, teori yang ada, atau metodologi terkait topik "${title}".
     2. Manfaat Praktis: Kegunaan hasil penelitian bagi pihak-pihak tertentu (misalnya: industri, pemerintah, masyarakat, praktisi) atau sebagai dasar untuk tindakan/kebijakan.
E. Sistematika Penulisan
   - Uraikan secara singkat isi dari masing-masing bab dalam skripsi ini (Bab I sampai Bab V).
--- AKHIR BAB I: PENDAHULUAN ---

--- AWAL BAB II: TINJAUAN PUSTAKA ---
A. Landasan Teori
   - Jelaskan secara komprehensif 2-3 konsep atau teori utama yang paling fundamental dan relevan sebagai dasar penelitian dengan judul "${title}".
   - Untuk setiap teori: Uraikan definisi, asumsi dasar, proposisi utama, dan analisis relevansinya.
   - (Adios: Pengguna harus memastikan teori yang dipilih benar-benar relevan dan pembahasannya mendalam, serta menambahkan sitasi dari sumber-sumber kredibel.)
   - [UNTUK SETIAP TEORI UTAMA, REVIEW DAN PASTIKAN KEDALAMAN SERTA RELEVANSINYA. TAMBAHKAN REFERENSI KUNCI ANDA DI SINI.]
B. Penelitian Terdahulu (Studi Relevan)
   - Sajikan review terhadap minimal 3 penelitian terdahulu yang sangat relevan dengan topik "${title}" (dalam 5-10 tahun terakhir).
   - Buat tabel perbandingan (Peneliti & Tahun, Judul, Metode, Temuan, Keterkaitan).
   - (Adios: Pengguna harus mencari dan memasukkan penelitian terdahulu yang paling relevan dan mutakhir.)
   - [MASUKKAN DATA PENELITIAN TERDAHULU YANG SPESIFIK (minimal 3) SESUAI FORMAT TABEL YANG DIMINTA.]
C. Kerangka Pemikiran atau Hipotesis
   - Sajikan kerangka pemikiran (kualitatif/eksploratif) atau rumuskan hipotesis (kuantitatif). Gunakan diagram ASCII jika relevan.
   - (Adios: Pengguna harus memvalidasi atau mengembangkan kerangka pemikiran/hipotesis ini agar sesuai dengan desain penelitiannya.)
   - [GAMBARKAN ATAU JELASKAN SECARA RINCI KERANGKA PEMIKIRAN/HIPOTESIS ANDA DI SINI. JIKA DIAGRAM, BUAT DALAM ASCII ART YANG JELAS.]
--- AKHIR BAB II: TINJAUAN PUSTAKA ---

--- AWAL BAB III: METODE PENELITIAN ---
(Adios: Bab ini krusial. Saya akan memberikan kerangka umum. Pengguna harus mengisi detail spesifik, justifikasi, dan prosedur yang sesuai dengan penelitiannya.)
A. Jenis Penelitian
   - Jelaskan jenis penelitian (kualitatif, kuantitatif, campuran, R&D).
   - [JUSTIFIKASI PEMILIHAN JENIS PENELITIAN ANDA SECARA DETAIL MENGAPA PALING TEPAT UNTUK MENJAWAB RUMUSAN MASALAH "${title}".]
B. Populasi dan Sampel (atau Subjek Penelitian jika Kualitatif)
   - Deskripsikan populasi target atau konteks subjek penelitian. Jelaskan teknik pengambilan sampel/pemilihan subjek, kriteria inklusi/eksklusi, dan target ukuran sampel/jumlah partisipan.
   - [DESKRIPSIKAN KARAKTERISTIK POPULASI SPESIFIK ATAU KONTEKS SUBJEK PENELITIAN ANDA.]
   - [RINCIKAN TEKNIK PENGAMBILAN SAMPEL/PEMILIHAN SUBJEK YANG ANDA GUNAKAN, KRITERIA, DAN JUSTIFIKASI TARGET UKURAN SAMPEL/JUMLAH PARTISIPANNYA.]
C. Teknik Pengumpulan Data
   - Sebutkan dan jelaskan teknik utama (wawancara, observasi, kuesioner, studi dokumen, dll.) beserta instrumennya. Jelaskan bagaimana validitas dan reliabilitas instrumen diupayakan (jika relevan).
   - [DETAILKAN INSTRUMEN PENGUMPULAN DATA ANDA (misalnya, daftar pertanyaan wawancara semi-terstruktur, item kuesioner skala Likert, lembar observasi partisipan) DAN BAGAIMANA PROSEDUR PENGAMBILAN DATA AKAN DILAKUKAN. JELASKAN UPAYA VALIDITAS (misal: triangulasi, expert judgment) & RELIABILITAS INSTRUMEN (misal: uji coba, konsistensi internal). ]
D. Teknik Analisis Data
   - Jelaskan langkah-langkah atau metode analisis data sesuai jenis penelitian.
   - (Adios: Untuk Kualitatif, sebutkan model analisis seperti Tematik, Naratif, Grounded Theory, dll. Untuk Kuantitatif, sebutkan uji statistik yang akan digunakan).
   - [JELASKAN SECARA SPESIFIK LANGKAH-LANGKAH TEKNIK ANALISIS DATA YANG AKAN ANDA TERAPKAN PADA DATA YANG NANTINYA ANDA KUMPULKAN. SEBUTKAN SOFTWARE JIKA ADA (misal: SPSS, NVivo).]
E. Diagram Alir Penelitian (ASCII Art Detail)
   - Buat diagram alir penelitian yang lebih detail dalam bentuk text-based ASCII art, menunjukkan tahapan dari awal hingga akhir.
     (Adios: Berikut contoh format diagram alir. Sesuaikan dengan tahapan spesifik penelitian Anda.)
     [Identifikasi Masalah & Studi Awal ("${title}")] --> [Perumusan Masalah & Tujuan]
                     |                                      |
                     V                                      V
     [Studi Literatur Mendalam (Teori & Studi Terdahulu)] --> [Pengembangan Desain & Instrumen Penelitian] --(Uji Coba & Validasi Instrumen)--> [Instrumen Final]
                     |                                      |
                     V                                      V
     [Penentuan & Pengambilan Sampel/Pemilihan Partisipan Sesuai Kriteria] --> [PROSES PENGUMPULAN DATA UTAMA ANDA]
                                                                      | (Contoh: Wawancara Mendalam, Survei Skala Besar, Observasi Partisipan)
                                                                      V
     [PENGOLAHAN & ANALISIS DATA ANDA SESUAI TEKNIK YANG DIPILIH] --> [Interpretasi Hasil & Temuan Utama]
                     |                                                         |
                     V                                                         V
     [Kesimpulan & Saran Penelitian] <---------------------- [Pembahasan Komprehensif dengan Teori & Penelitian Lain]
           |
           V
     [PENULISAN LAPORAN SKRIPSI FINAL]
--- AKHIR BAB III: METODE PENELITIAN ---

--- AWAL BAB IV: HASIL DAN PEMBAHASAN ---
(Adios: Bab ini adalah inti dari penelitian Anda. Saya akan membuatkan kerangka dan contoh bagaimana Anda bisa menyajikan serta membahas temuan Anda. Pastikan Anda mengganti semua contoh data fiktif dan analisis fiktif dengan data dan analisis hasil penelitian Anda yang sebenarnya.)

A. Deskripsi Data / Penyajian Temuan Penelitian
   (Adios: Sajikan di sini gambaran umum data yang telah Anda kumpulkan atau temuan utama penelitian Anda secara deskriptif. Struktur penyajian akan berbeda untuk kualitatif dan kuantitatif. Berikut adalah contoh bagaimana Anda bisa menyusunnya, GANTI DENGAN DATA ANDA.)
   - Jika Penelitian Kualitatif:
     [MASUKKAN DESKRIPSI TEMUAN KUALITATIF UTAMA ANDA DI SINI. ORGANISIR BERDASARKAN TEMA-TEMA KUNCI YANG MUNCUL DARI ANALISIS DATA ANDA. CONTOH NARASI PEMBUKA: "Berdasarkan analisis [jumlah] wawancara mendalam dengan [jumlah] partisipan dan [jumlah] sesi observasi selama [periode waktu], ditemukan beberapa tema kunci yang signifikan terkait [aspek dari judul: "${title}"]. Tema-tema ini akan diuraikan secara detail di bawah ini, didukung oleh kutipan partisipan yang representatif untuk menjaga otentisitas temuan."]
     (Adios akan memberikan contoh struktur untuk satu tema, misal:)
     **Tema 1: [Judul Tema yang Anda Identifikasi dari Data, Relevan dengan "${title}"]**
     [Adios membuat deskripsi singkat tema ini, menjelaskan inti dari tema tersebut berdasarkan judul. Kemudian:]
     [BERIKAN DESKRIPSI DETAIL MENGENAI TEMA INI, DIDUKUNG OLEH BEBERAPA KUTIPAN PARTISIPAN YANG REPRESENTATIF (ANONIMKAN PARTISIPAN, MISAL P1, P2). JELASKAN KONTEKS DARI SETIAP KUTIPAN. CONTOH: "Tema ini menggambarkan [deskripsi singkat tema]. Hal ini terlihat jelas dari pernyataan P1, seorang [deskripsi singkat P1], yang mengungkapkan: '...[kutipan langsung yang relevan dan mendukung tema]...' (Wawancara P1, Tanggal). Selain itu, P3 juga menyampaikan pandangan serupa: '...[kutipan lain]...' (Wawancara P3, Tanggal). Data observasi juga mencatat [deskripsi observasi yang mendukung tema]."]
     [ULANGI STRUKTUR PENYAJIAN TEMA INI UNTUK SEMUA TEMA UTAMA YANG ANDA IDENTIFIKASI DARI DATA PENELITIAN ANDA.]
   - Jika Penelitian Kuantitatif:
     [MASUKKAN DESKRIPSI DATA KUANTITATIF ANDA DI SINI. AWALI DENGAN DESKRIPSI SAMPEL/RESPONDEN. CONTOH NARASI: "Data kuantitatif dikumpulkan dari [jumlah N] responden yang berpartisipasi dalam survei/eksperimen ini. Karakteristik demografi responden (misalnya, usia, jenis kelamin, tingkat pendidikan) disajikan secara detail pada Tabel 4.1."]
     (Adios akan memberikan contoh bagaimana tabel frekuensi atau statistik deskriptif bisa disajikan)
     **Tabel 4.1 Contoh Format: Karakteristik Demografi Responden (N=[Isi Jumlah N Aktual Anda])**
     | Karakteristik | Kategori         | Frekuensi (f) | Persentase (%) |
     |---------------|------------------|---------------|----------------|
     | Usia          | [Contoh Rentang1]| [Isi Data Anda] | [Isi Data Anda]|
     |               | [Contoh Rentang2]| [Isi Data Anda] | [Isi Data Anda]|
     | Jenis Kelamin | Laki-laki        | [Isi Data Anda] | [Isi Data Anda]|
     |               | Perempuan        | [Isi Data Anda] | [Isi Data Anda]|
     | Pendidikan    | [Kategori Anda]  | [Isi Data Anda] | [Isi Data Anda]|
     (Adios: Ganti tabel di atas dengan data karakteristik sampel aktual Anda dan variabel yang relevan.)
     [SELANJUTNYA, SAJIKAN STATISTIK DESKRIPTIF (MEAN, STANDAR DEVIASI, MIN, MAX, DLL.) UNTUK VARIABEL-VARIABEL PENELITIAN UTAMA ANDA. GUNAKAN TABEL JIKA PERLU. CONTOH: "Statistik deskriptif untuk variabel [Nama Variabel Penelitian X] dapat dilihat pada Tabel 4.2."]
     **Tabel 4.2 Contoh Format: Statistik Deskriptif Variabel [Nama Variabel X]**
     | Indikator/Item Pertanyaan | Mean | SD   | Min | Max |
     |---------------------------|------|------|-----|-----|
     | [Indikator 1 Var X]       | [Data] | [Data] | [Data]|[Data]|
     | [Indikator 2 Var X]       | [Data] | [Data] | [Data]|[Data]|
     [MASUKKAN TABEL STATISTIK DESKRIPTIF UNTUK SEMUA VARIABEL-VARIABEL UTAMA PENELITIAN ANDA DI SINI.]

B. Hasil Analisis Data (Pengujian Hipotesis atau Jawaban atas Rumusan Masalah)
   (Adios: Di bagian ini, Anda akan menyajikan hasil analisis data yang lebih mendalam, seperti hasil uji statistik untuk penelitian kuantitatif, atau analisis interpretatif untuk penelitian kualitatif yang menjawab rumusan masalah. Berikut adalah contoh bagaimana Anda dapat menarasikannya.)
   - Jika Penelitian Kualitatif:
     [JELASKAN BAGAIMANA TEMA-TEMA YANG TELAH DIIDENTIFIKASI PADA BAGIAN A SECARA LANGSUNG MENJAWAB RUMUSAN MASALAH ANDA. CONTOH NARASI: "Untuk menjawab rumusan masalah pertama, yaitu '[Tulis ulang RM1 Anda]', analisis terhadap tema '[Nama Tema Relevan dari A]' dan '[Nama Tema Lain Relevan dari A]' menunjukkan bahwa [jawaban interpretatif untuk RM1 berdasarkan analisis tema tersebut]. Secara spesifik, [detail temuan dari analisis tema yang menjawab RM1]..."]
     [ULANGI UNTUK SETIAP RUMUSAN MASALAH, HUBUNGKAN DENGAN TEMA-TEMA YANG TELAH DIIDENTIFIKASI DAN DIANALISIS SECARA MENDALAM.]
   - Jika Penelitian Kuantitatif:
     [SAJIKAN HASIL UJI HIPOTESIS ATAU ANALISIS STATISTIK LAINNYA UNTUK SETIAP RUMUSAN MASALAH. CONTOH NARASI: "Untuk menguji hipotesis H1: '[Bunyi hipotesis H1 Anda]', dilakukan uji [nama uji statistik, misal: Korelasi Pearson]. Hasil analisis (lihat Tabel 4.X) menunjukkan bahwa terdapat hubungan yang [positif/negatif] dan [signifikan/tidak signifikan] antara variabel [X] dan variabel [Y] (r = [nilai r], p = [nilai p, misal: .001]). Dengan demikian, hipotesis H1 [diterima/ditolak]."]
     [MASUKKAN HASIL UJI STATISTIK SPESIFIK UNTUK SETIAP RUMUSAN MASALAH/HIPOTESIS ANDA, LENGKAP DENGAN NILAI STATISTIK (misal: r, t, F, Chi-square), df (jika ada), DAN p-value. GUNAKAN TABEL UNTUK MENYAJIKAN HASIL UJI SECARA RINGKAS JIKA PERLU.]
     **Tabel 4.X Contoh: Hasil Uji [Nama Uji Statistik] untuk Hipotesis [H_Anda]**
     | Variabel Terkait | Koefisien | Nilai Statistik | p-value | Keputusan |
     |------------------|-----------|-----------------|---------|-----------|
     | [Variabel X & Y] | [Nilai]   | [Nilai t/F/dll] | [Nilai] | [Diterima/Ditolak] |
     (Adios: Pastikan Anda melaporkan hasil statistik secara lengkap sesuai panduan dan merujuk ke tabel jika ada.)

C. Pembahasan Hasil Penelitian
   (Adios: Di sini, Anda akan menginterpretasikan makna dari hasil analisis Anda dan membahasnya secara mendalam dalam konteks teori serta penelitian terdahulu. Lakukan ini untuk setiap temuan penting atau jawaban atas rumusan masalah.)
   **Sub-Bab Sesuai Rumusan Masalah/Hipotesis 1: [Judul Sub-Bab Mengacu pada RM1/H1 atau Tema Utama dari Kualitatif]**
      1. **Interpretasi Mendalam Temuan**:
         [APA MAKNA SEBENARNYA DARI TEMUAN ANDA TERKAIT RM1/H1 ATAU TEMA UTAMA INI? JELASKAN SECARA RINCI DAN KRITIS. CONTOH FIKTIF JIKA KUANTITATIF: "Temuan bahwa terdapat hubungan positif signifikan antara variabel [X] dan [Y] (r=[nilai], p<0.05) mengindikasikan bahwa seiring dengan meningkatnya [Variabel X], maka [Variabel Y] juga cenderung meningkat dalam konteks [populasi/sampel Anda] terkait dengan '${title}'. Implikasi praktisnya adalah..." CONTOH FIKTIF JIKA KUALITATIF: "Identifikasi tema '[Judul Tema dari A]' yang menyoroti [aspek penting tema] memberikan pemahaman bahwa partisipan dalam penelitian ini mempersepsikan [interpretasi makna tema tersebut secara mendalam dan kritis, kaitkan dengan konteks penelitian]..."]
         (Adios akan memberikan contoh interpretasi untuk satu temuan fiktif berdasarkan judul)
      2. **Keterkaitan dengan Landasan Teori (Bab II)**:
         [BAGAIMANA TEMUAN INI BERKAITAN DENGAN TEORI-TEORI YANG TELAH ANDA PAPARKAN DI BAB II? APAKAH TEMUAN ANDA MENDUKUNG, MEMPERLUAS, MENOLAK, ATAU MEMODIFIKASI TEORI YANG ADA? DISKUSIKAN DENGAN DETAIL DAN ARGUMENTATIF. CONTOH FIKTIF: "Temuan ini secara umum sejalan dengan Teori [X] yang dikemukakan oleh [Tokoh Teori] (Tahun), yang menyatakan bahwa [aspek teori yang relevan]. Secara spesifik, [aspek temuan] mendukung proposisi [proposisi teori]. Namun, temuan ini juga memberikan nuansa baru pada Teori [Y] dengan menunjukkan bahwa [detail spesifik yang memperkaya atau menantang teori Y]..."]
         (Adios akan memberikan contoh diskusi dengan teori)
      3. **Perbandingan dengan Penelitian Terdahulu (Bab II)**:
         [BAGAIMANA TEMUAN ANDA JIKA DIBANDINGKAN DENGAN HASIL PENELITIAN TERDAHULU YANG RELEVAN YANG TELAH ANDA REVIEW DI BAB II? APAKAH ADA KESAMAAN, PERBEDAAN, ATAU KONSISTENSI? DISKUSIKAN KEMUNGKINAN PENYEBAB PERBEDAAN (misal: perbedaan konteks, sampel, metodologi, atau perkembangan waktu) DAN IMPLIKASINYA. CONTOH FIKTIF: "Hasil penelitian ini konsisten dengan temuan oleh [Peneliti A] ([Tahun]) yang juga menemukan bahwa [kesamaan temuan] dalam konteks [konteks penelitian Peneliti A]. Namun, berbeda dengan hasil penelitian [Peneliti B] ([Tahun]) yang menemukan [perbedaan temuan] pada populasi [populasi Peneliti B], hal ini mungkin disebabkan oleh [analisis kemungkinan penyebab perbedaan, misal: perbedaan budaya, kebijakan, atau instrumen yang digunakan]."]
         (Adios akan memberikan contoh perbandingan)
   [ULANGI STRUKTUR INTERPRETASI DAN PEMBAHASAN DI ATAS UNTUK SETIAP RUMUSAN MASALAH/HIPOTESIS/TEMA UTAMA LAINNYA YANG SIGNIFIKAN]

   **Pembahasan Umum Implikasi Lebih Luas dan Keterbatasan Penelitian**
      4. **Implikasi Temuan (Teoritis dan Praktis Secara Menyeluruh)**:
         [SETELAH MEMBAHAS SETIAP TEMUAN SECARA SPESIFIK, APA IMPLIKASI TEORITIS (BAGI PENGEMBANGAN ILMU PENGETAHUAN DI BIDANG INI) DAN IMPLIKASI PRAKTIS (UNTUK STAKEHOLDER SEPERTI PRAKTISI, PEMBUAT KEBIJAKAN, MASYARAKAT UMUM) DARI KESELURUHAN TEMUAN PENELITIAN ANDA? JELASKAN SECARA KOMPREHENSIF.]
      5. **Keterbatasan Penelitian**:
         (Adios: Mengakui keterbatasan penelitian Anda secara jujur dan transparan akan meningkatkan kredibilitas skripsi Anda. Ini juga menunjukkan pemahaman Anda terhadap proses penelitian.)
         [SEBUTKAN DAN JELASKAN SECARA OBJEKTIF KETERBATASAN-KETERBATASAN DALAM PENELITIAN ANDA. SETIAP POIN HARUS JELAS. CONTOH: "Penelitian ini, meskipun telah diupayakan secara maksimal, memiliki beberapa keterbatasan yang perlu dipertimbangkan, antara lain: (1) Keterbatasan Metodologis: [contoh spesifik, misal: penggunaan sampel non-probability (convenience sampling) yang membatasi generalisasi hasil penelitian ke populasi yang lebih luas], (2) Keterbatasan Ruang Lingkup: [contoh spesifik, misal: penelitian ini hanya dilakukan pada satu konteks geografis/institusi tertentu, sehingga hasilnya mungkin tidak dapat langsung diterapkan pada konteks lain], (3) Keterbatasan Instrumen: [contoh spesifik, misal: kuesioner yang digunakan mungkin memiliki potensi bias respons sosial meskipun telah diuji validitas dan reliabilitasnya], (4) Potensi Bias Peneliti: [contoh spesifik, misal: dalam penelitian kualitatif, interpretasi data mungkin dipengaruhi oleh latar belakang dan perspektif peneliti meskipun upaya objektivitas telah dilakukan melalui triangulasi]."]
--- AKHIR BAB IV: HASIL DAN PEMBAHASAN ---

--- AWAL BAB V: PENUTUP ---
(Adios: Kesimpulan dan Saran ini harus didasarkan secara ketat pada temuan dan pembahasan di Bab IV. Pastikan untuk merevisinya secara menyeluruh agar sesuai dengan hasil penelitian Anda yang sebenarnya setelah Anda mengisi Bab IV.)
A. Kesimpulan
   - Buatlah poin-poin kesimpulan utama (jumlahnya idealnya sama dengan jumlah rumusan masalah) yang secara langsung, ringkas, dan tegas menjawab setiap rumusan masalah yang telah ditetapkan di Bab I. Kesimpulan harus didasarkan HANYA pada hasil dan pembahasan di Bab IV, bukan opini baru.
   - [UNTUK SETIAP RUMUSAN MASALAH, TULISKAN KESIMPULAN SPESIFIKNYA DI SINI. CONTOH UNTUK RM1: "Berdasarkan hasil penelitian dan pembahasan, dapat disimpulkan bahwa terkait rumusan masalah pertama mengenai [ringkasan RM1], ditemukan bahwa [jawaban langsung dan ringkas untuk RM1 berdasarkan temuan di Bab IV]..."]
   - [ULANGI UNTUK SETIAP RUMUSAN MASALAH.]
B. Saran
   - Berikan saran yang konstruktif, spesifik, actionable, dan relevan (minimal 2-3 poin untuk masing-masing kategori praktis dan akademis), berdasarkan kesimpulan penelitian:
     1. Saran Praktis/Implikatif: Ditujukan kepada pihak-pihak yang dapat memanfaatkan hasil penelitian ini secara langsung (misalnya, jika topik tentang pendidikan, saran untuk sekolah/guru/kementerian; jika tentang bisnis, saran untuk manajer/perusahaan).
        [SARAN PRAKTIS SPESIFIK 1: Kepada [Pihak Tertentu], disarankan untuk [tindakan konkret berdasarkan temuan] guna [manfaat yang diharapkan].]
        [SARAN PRAKTIS SPESIFIK 2: ...]
     2. Saran Akademis/Untuk Penelitian Selanjutnya: Arah atau topik penelitian lebih lanjut yang bisa dikembangkan dari penelitian ini, perbaikan metodologis untuk penelitian sejenis di masa depan, atau area yang belum terjawab oleh penelitian ini.
        [SARAN AKADEMIS SPESIFIK 1: Peneliti selanjutnya disarankan untuk [mengembangkan/memperdalam aspek tertentu dari penelitian ini, misal: menggunakan sampel yang lebih besar/beragam, metodologi yang berbeda, atau meneliti variabel lain yang mungkin terkait]...]
        [SARAN AKADEMIS SPESIFIK 2: ...]
--- AKHIR BAB V: PENUTUP ---

Pastikan output Anda terstruktur dengan jelas menggunakan penanda --- AWAL ... --- dan --- AKHIR ... --- untuk setiap bab dan sub-bab utama.
Gunakan placeholder yang jelas seperti [CONTOH_PLACEHOLDER_ANDA] dan berikan panduan singkat di sekitar placeholder tersebut agar pengguna tahu di mana dan bagaimana harus memasukkan input spesifik mereka.
Hindari kalimat pembuka atau penutup yang tidak perlu di setiap bagian, langsung saja ke konten yang diminta sesuai struktur.
Buatlah diagram (jika ada dan diminta) menggunakan teks/ASCII art yang jelas dan informatif.
Konten harus cerdas, valid, dan berkualitas tinggi, berfungsi sebagai kerangka kerja skripsi final yang siap diisi, divalidasi, dan dikembangkan lebih lanjut oleh pengguna.
Upayakan total output mendekati 115.000 karakter atau sekitar 12.000 kata dengan mengembangkan setiap bagian secara mendalam, sambil memberikan ruang yang cukup bagi pengguna untuk kontribusi utamanya dalam mengisi placeholder dengan data dan analisis mereka sendiri.
`;
  const systemInstruction = "Anda adalah Adios, Asisten Digital Olah Skripsi yang sangat kompeten, cerdas, dan teliti. Tugas Anda adalah menghasilkan NASKAH SKRIPSI LENGKAP (Daftar Isi + 5 BAB) berdasarkan judul spesifik dan instruksi detail yang diberikan. Peran utama Anda adalah membuat kerangka kerja yang sangat detail dan terstruktur, lengkap dengan penjelasan konseptual, contoh-contoh relevan, dan **placeholder yang jelas** di mana input spesifik, data penelitian aktual, analisis mendalam, dan justifikasi dari pengguna sangat diperlukan. Tujuan Anda adalah membantu pengguna memulai dengan struktur yang kuat dan panduan konten yang kaya, yang kemudian dapat mereka validasi, isi, kembangkan, dan personalisasi dengan penelitian mereka sendiri untuk menghasilkan naskah skripsi final berkualitas tinggi. Ikuti target panjang keseluruhan mendekati 115.000 karakter atau 12.000 kata. Pastikan semua yang ditulis relevan dengan judul, mendalam, analitis, 'to the point', dan berkualitas setara naskah final yang siap direview, dengan penekanan pada kemudahan validasi dan pengisian oleh pengguna.";

  if (!API_KEY || API_KEY === "MISSING_API_KEY_PLACEHOLDER") {
    async function* errorStream(): AsyncIterable<GenerateContentResponse> {
      yield {
        // Simulate a GenerateContentResponse structure with an error text
        text: "Error: API Key tidak dikonfigurasi dengan benar.",
        // Add other mandatory fields for GenerateContentResponse if any, or ensure .text is primary
      } as unknown as GenerateContentResponse; // Cast if structure is simplified
    }
    return errorStream();
  }

  try {
    const streamRequestParams = {
      model: GEMINI_TEXT_MODEL,
      contents: draftPrompt,
      config: {
        systemInstruction: systemInstruction,
      },
    };
    const responseStream = await ai.models.generateContentStream(streamRequestParams);
    return responseStream;
  } catch (error) {
    console.error("Gemini API stream call failed:", error);
    async function* errorStreamCatch(): AsyncIterable<GenerateContentResponse> {
      let errorMessage = "Terjadi kesalahan saat memulai streaming dari Adios. Silakan coba lagi.";
      if (error instanceof Error) {
        if (error.message.includes("API key not valid") || error.message.includes("API_KEY_INVALID")) {
          errorMessage = `Error: API Key tidak valid. Pastikan API Key Anda benar dan memiliki izin yang diperlukan.`;
        } else {
          errorMessage = `Error streaming: ${error.message}`;
        }
      }
       yield { text: errorMessage } as unknown as GenerateContentResponse;
    }
    return errorStreamCatch();
  }
};


export const getLogicAnalysis = async (textToAnalyze: string): Promise<GeminiResponse> => {
  const prompt = `
Analisis teks berikut secara mendalam dari perspektif argumen logis, retorika, dan penulisan akademik.
Teks Pengguna untuk Dianalisis:
---
${textToAnalyze}
---

Tugas Anda adalah memberikan "Analisis Argumen & Koherensi Logis (Adios LogicSense)".
Format output Anda HARUS berupa objek JSON yang valid dengan struktur berikut:
{
  "identified_claims": ["Klaim utama 1 yang teridentifikasi dalam teks.", "Klaim utama 2 jika ada, dst."],
  "support_evaluation": {
    "assessment": "Penilaian umum tentang seberapa baik klaim didukung oleh bukti atau alasan dalam teks.",
    "evidence_type": "Jenis bukti yang digunakan (misalnya, data statistik, kutipan ahli, contoh kasus, penalaran logis). Jika tidak ada, sebutkan.",
    "suggestions_for_improvement": "Saran spesifik jika dukungan dirasa kurang (misalnya, 'Tambahkan data kuantitatif untuk mendukung klaim X', 'Berikan contoh konkret untuk Y')."
  },
  "logical_fallacies": [
    {
      "fallacy_name": "Nama kesalahan logika yang teridentifikasi (misal: Generalisasi Terburu-buru, Ad Hominem).",
      "explanation": "Penjelasan singkat mengapa bagian teks tersebut dapat dianggap mengandung kesalahan logika ini.",
      "quote_from_text": "Kutipan singkat dari teks pengguna yang menunjukkan potensi kesalahan tersebut."
    }
  ],
  "coherence_and_flow": {
    "assessment": "Penilaian umum tentang kelancaran transisi antar kalimat/ide dan kejelasan alur argumen secara keseluruhan.",
    "problem_areas": ["Identifikasi bagian spesifik yang mungkin terasa melompat, kurang terhubung, atau ambigu."]
  },
  "improvement_suggestions": [
    "Saran konstruktif dan spesifik 1 tentang bagaimana argumen dapat diperkuat atau celah logika ditutup.",
    "Saran konstruktif dan spesifik 2 (misalnya, 'Pertimbangkan untuk merestrukturisasi paragraf X agar lebih fokus pada klaim utama', 'Gunakan kata transisi yang lebih eksplisit antara ide Y dan Z')."
  ]
}
Jika tidak ada kesalahan logika yang ditemukan, "logical_fallacies" bisa berupa array kosong [].
Pastikan output HANYA berupa objek JSON yang valid, tanpa teks tambahan sebelum atau sesudahnya.
`;
  return generateContent(prompt, "Anda adalah Adios LogicSense, seorang pakar analisis argumen logis. Anda menganalisis teks dan memberikan output dalam format JSON.", true);
};

