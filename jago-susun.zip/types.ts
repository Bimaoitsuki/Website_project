
export enum Feature {
  AUTO_FORMATTING = 'Auto-Formatting Dokumen',
  SAMPLE_DOCS = 'Dokumen Contoh Lengkap',
  BIBLIOGRAPHY = 'Daftar Pustaka Otomatis',
  CHECKLIST = 'Checklist Final Submit',
  PARAPHRASING = 'AI Turnitin Shield (Parafrase)',
  LOGIC_ANALYSIS = 'Analisis Argumen & Koherensi Logis (Adios LogicSense)',
  DATA_VIZ = 'Rekomendasi Visualisasi Data',
  PRESENTATION = 'Outline Presentasi Sidang',
  AI_THESIS_DRAFT_GENERATOR = 'Generator Draf Skripsi (AI)', // Changed from RANDOM_TITLE_GENERATOR
  INFORMATION = 'Informasi Aplikasi',
}

export interface ChecklistItem {
  id: string;
  text: string;
  checked: boolean;
  details?: string; // Optional details or tips
}

export interface ChecklistCategory {
  title: string;
  items: ChecklistItem[];
}

export enum CitationStyle {
  APA7 = "APA 7th Edition",
  IEEE = "IEEE",
  CHICAGO = "Chicago Author-Date",
  HARVARD = "Harvard Style"
}

export interface GroundingChunkWeb {
  uri: string;
  title: string;
}
export interface GroundingChunk {
  web: GroundingChunkWeb;
}
export interface GroundingMetadata {
  groundingChunks?: GroundingChunk[];
}
export interface Candidate {
  groundingMetadata?: GroundingMetadata;
}

export interface GeminiResponse {
  text: string;
  candidates?: Candidate[];
}

// --- New Types for JSON Responses ---

export interface VizRecommendationItem {
  type: string;
  reason: string;
  example_representation?: string;
  axes_placeholders?: { x_axis: string; y_axis: string };
  suggested_title?: string;
}
export interface VizRecommendationResponse {
  recommendations: VizRecommendationItem[];
}

export interface PresentationSlide {
  slide_number?: string; // Made optional as AI might not always provide it
  title: string;
  estimated_time?: string;
  main_points: string[];
  suggested_visual?: string;
}
export interface PresentationOutlineResponse {
  slides: PresentationSlide[];
  general_tips?: string[];
}

// For Custom Checklist, AI will return an array of objects matching this structure
// but 'id' and 'checked' will be handled client-side after parsing.
export interface AiChecklistItem {
    text: string;
    details?: string;
}
export interface AiChecklistCategory {
    title: string;
    items: AiChecklistItem[];
}
export interface CustomChecklistResponse {
    categories: AiChecklistCategory[];
}


export interface LogicAnalysisFallacy {
  fallacy_name: string;
  explanation: string;
  quote_from_text: string;
}
export interface LogicAnalysisResponse {
  identified_claims: string[];
  support_evaluation: {
    assessment: string;
    evidence_type?: string;
    suggestions_for_improvement?: string;
  };
  logical_fallacies: LogicAnalysisFallacy[] | string; // string if "no fallacies found"
  coherence_and_flow: {
    assessment: string;
    problem_areas?: string[];
  };
  improvement_suggestions: string[];
}

// Utility type for parsed JSON responses that might have an error
export type ParsedJsonResponse<T> = T | { error: string; rawText: string };
